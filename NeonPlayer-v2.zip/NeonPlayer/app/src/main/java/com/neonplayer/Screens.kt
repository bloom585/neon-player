package com.neonplayer

import androidx.compose.animation.core.animate
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.zIndex
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import kotlin.math.max

@Composable
fun PlayerScreen(vm: PlayerViewModel, onOpenList: () -> Unit) {
    val hasTrack = vm.currentIndex >= 0

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 24.dp, vertical = 12.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
        ) {
            NeonButton(
                size = 72.dp,
                description = if (vm.repeatOne) "Повтор одной песни включён" else "Повторять одну песню",
                onClick = vm::toggleRepeatOne,
                filled = vm.repeatOne,
            ) { iconRepeat(it, vm.repeatOne) }

            NeonButton(
                size = 72.dp,
                description = "Список треков",
                onClick = onOpenList,
            ) { iconList(it) }
        }

        BoxWithConstraints(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth(),
            contentAlignment = Alignment.Center,
        ) {
            val side = minOf(maxWidth, maxHeight, 280.dp)
            NeonDisc(playing = vm.isPlaying, modifier = Modifier.size(side))
        }

        Text(
            text = if (hasTrack) vm.title else "Выберите трек",
            color = Neon.Text,
            fontSize = 24.sp,
            fontWeight = FontWeight.Bold,
            maxLines = 2,
            overflow = TextOverflow.Ellipsis,
            textAlign = TextAlign.Center,
            modifier = Modifier.fillMaxWidth(),
        )
        Spacer(Modifier.height(6.dp))
        Text(
            text = if (hasTrack) vm.artist else " ",
            color = Neon.Muted,
            fontSize = 16.sp,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            textAlign = TextAlign.Center,
            modifier = Modifier.fillMaxWidth(),
        )

        Spacer(Modifier.height(20.dp))

        NeonSeekBar(
            positionMs = vm.positionMs,
            durationMs = vm.durationMs,
            enabled = hasTrack,
            onSeek = vm::seekTo,
            modifier = Modifier.fillMaxWidth(),
        )

        Spacer(Modifier.height(20.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceEvenly,
            verticalAlignment = Alignment.CenterVertically,
        ) {
            NeonButton(
                size = 84.dp,
                description = "Предыдущий трек",
                onClick = vm::previous,
            ) { iconPrevious(it) }

            NeonButton(
                size = 128.dp,
                description = if (vm.isPlaying) "Пауза" else "Играть",
                onClick = vm::togglePlay,
                filled = true,
            ) { if (vm.isPlaying) iconPause(it) else iconPlay(it) }

            NeonButton(
                size = 84.dp,
                description = "Следующий трек",
                onClick = vm::next,
            ) { iconNext(it) }
        }

        Spacer(Modifier.height(28.dp))
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun TrackListScreen(vm: PlayerViewModel, onBack: () -> Unit) {
    val listState = rememberLazyListState()
    val scope = rememberCoroutineScope()

    var draggedId by remember { mutableStateOf<String?>(null) }
    var dragOffset by remember { mutableFloatStateOf(0f) }
    var settleJob by remember { mutableStateOf<Job?>(null) }

    val density = LocalDensity.current
    val edgePx = with(density) { 72.dp.toPx() }
    val scrollStepPx = with(density) { 14.dp.toPx() }

    fun startDrag(id: String) {
        settleJob?.cancel()
        draggedId = id
        dragOffset = 0f
    }

    fun dragBy(dy: Float) {
        val id = draggedId ?: return
        dragOffset += dy

        val info = listState.layoutInfo
        val items = info.visibleItemsInfo
        val dragged = items.firstOrNull { it.key == id } ?: return
        val from = vm.tracks.indexOfFirst { it.mediaItem.mediaId == id }
        // Если список ещё не перерисовался после прошлой перестановки — ждём
        if (from < 0 || dragged.index != from) return

        val center = dragged.offset + dragged.size / 2f + dragOffset
        val target = items.firstOrNull {
            it.key != id && center >= it.offset && center <= it.offset + it.size
        }
        if (target != null && target.index != from && target.index in vm.tracks.indices) {
            vm.moveTrack(from, target.index)
            val newOffset = if (target.index > from) {
                target.offset + target.size - dragged.size
            } else {
                target.offset
            }
            dragOffset -= (newOffset - dragged.offset)
            return
        }

        // Прокрутка списка, когда трек подтянули к краю экрана
        val top = dragged.offset + dragOffset
        val bottom = top + dragged.size
        if (top < info.viewportStartOffset + edgePx) {
            dragOffset += listState.dispatchRawDelta(-scrollStepPx)
        } else if (bottom > info.viewportEndOffset - edgePx) {
            dragOffset += listState.dispatchRawDelta(scrollStepPx)
        }
    }

    fun endDrag() {
        vm.saveOrder()
        settleJob = scope.launch {
            animate(initialValue = dragOffset, targetValue = 0f, animationSpec = tween(180)) { value, _ ->
                dragOffset = value
            }
            draggedId = null
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 24.dp, vertical = 12.dp),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            NeonButton(
                size = 72.dp,
                description = "Закрыть список",
                onClick = onBack,
            ) { iconClose(it) }
            Spacer(Modifier.size(20.dp))
            Text("Треки", color = Neon.Text, fontSize = 28.sp, fontWeight = FontWeight.Bold)
        }

        if (vm.tracks.isEmpty()) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text("Музыка не найдена", color = Neon.Muted, fontSize = 18.sp)
            }
        } else {
            LazyColumn(
                state = listState,
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(top = 24.dp, bottom = 24.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp),
            ) {
                items(vm.tracks, key = { it.mediaItem.mediaId }) { track ->
                    val id = track.mediaItem.mediaId
                    val isDragged = id == draggedId

                    TrackRow(
                        track = track,
                        current = id == vm.currentMediaId,
                        dragged = isDragged,
                        modifier = if (isDragged) {
                            Modifier
                                .zIndex(1f)
                                .graphicsLayer {
                                    translationY = dragOffset
                                    scaleX = 1.03f
                                    scaleY = 1.03f
                                }
                        } else {
                            Modifier.animateItem()
                        },
                        onClick = {
                            vm.play(vm.tracks.indexOfFirst { it.mediaItem.mediaId == id })
                            onBack()
                        },
                        onDragStart = { startDrag(id) },
                        onDrag = { dy -> dragBy(dy) },
                        onDragEnd = { endDrag() },
                    )
                }
            }
        }
    }
}

@Composable
private fun TrackRow(
    track: Track,
    current: Boolean,
    dragged: Boolean,
    modifier: Modifier,
    onClick: () -> Unit,
    onDragStart: () -> Unit,
    onDrag: (Float) -> Unit,
    onDragEnd: () -> Unit,
) {
    val shape = RoundedCornerShape(22.dp)
    val interaction = remember { MutableInteractionSource() }
    val press = rememberPressGlow(interaction)
    val hot = max(press, if (dragged) 1f else 0f)
    val borderColor = lerp(if (current) Neon.Blue else Neon.Dim, Neon.Light, hot)

    val startCb by rememberUpdatedState(onDragStart)
    val dragCb by rememberUpdatedState(onDrag)
    val endCb by rememberUpdatedState(onDragEnd)

    Row(
        modifier = modifier
            .fillMaxWidth()
            .height(80.dp)
            .clip(shape)
            .background(Neon.Surface)
            .drawBehind { drawRect(Neon.Blue.copy(alpha = 0.18f * hot)) }
            .border(if (current || dragged) 2.dp else 1.dp, borderColor, shape)
            .clickable(interactionSource = interaction, indication = null, onClick = onClick)
            .padding(start = 20.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Column(Modifier.weight(1f)) {
            Text(
                text = track.title,
                color = if (current) Neon.Light else Neon.Text,
                fontSize = 18.sp,
                fontWeight = FontWeight.SemiBold,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
            Spacer(Modifier.height(2.dp))
            Text(
                text = track.artist,
                color = Neon.Muted,
                fontSize = 14.sp,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
        }
        Spacer(Modifier.size(12.dp))
        Text(formatTime(track.durationMs), color = Neon.Muted, fontSize = 14.sp)

        // Три черты справа: зажмите и ведите вверх или вниз
        Box(
            modifier = Modifier
                .width(68.dp)
                .fillMaxHeight()
                .clickable(
                    interactionSource = remember { MutableInteractionSource() },
                    indication = null,
                    onClick = {},
                )
                .pointerInput(track.mediaItem.mediaId) {
                    detectDragGestures(
                        onDragStart = { startCb() },
                        onDragEnd = { endCb() },
                        onDragCancel = { endCb() },
                        onDrag = { change, amount ->
                            change.consume()
                            dragCb(amount.y)
                        },
                    )
                },
            contentAlignment = Alignment.Center,
        ) {
            val gripColor = if (dragged) Neon.Light else Neon.Muted
            Canvas(Modifier.size(width = 28.dp, height = 20.dp)) { iconGrip(gripColor) }
        }
    }
}

@Composable
fun PermissionScreen(onRequest: () -> Unit, buttonText: String) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(32.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        NeonDisc(playing = false, modifier = Modifier.size(200.dp))
        Spacer(Modifier.height(40.dp))
        Text(
            "Нужен доступ к музыке на телефоне",
            color = Neon.Text,
            fontSize = 22.sp,
            fontWeight = FontWeight.Bold,
            textAlign = TextAlign.Center,
        )
        Spacer(Modifier.height(32.dp))
        NeonPillButton(text = buttonText, onClick = onRequest)
    }
}
