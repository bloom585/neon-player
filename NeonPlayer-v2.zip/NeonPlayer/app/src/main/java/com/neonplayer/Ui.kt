package com.neonplayer

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.PressInteraction
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.DpSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.flow.collectLatest
import kotlin.math.max

object Neon {
    val Bg = Color(0xFF04060D)
    val Surface = Color(0xFF0A1226)
    val Dim = Color(0xFF16233F)
    val Blue = Color(0xFF1E8BFF)
    val Light = Color(0xFF5CC8FF)
    val Text = Color(0xFFEAF4FF)
    val Muted = Color(0xFF7FA3CC)
}

@Composable
fun NeonTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Neon.Blue,
            background = Neon.Bg,
            surface = Neon.Surface,
            onBackground = Neon.Text,
            onSurface = Neon.Text,
        ),
        content = content,
    )
}

/**
 * Плавное свечение при касании: от 0 до 1.
 * При нажатии быстро разгорается, после отпускания медленно гаснет.
 * Даже при самом коротком касании свечение успевает разгореться полностью.
 */
@Composable
fun rememberPressGlow(source: MutableInteractionSource): Float {
    val glow = remember { Animatable(0f) }
    LaunchedEffect(source) {
        source.interactions.collectLatest { interaction ->
            when (interaction) {
                is PressInteraction.Press -> {
                    glow.animateTo(1f, tween(160))
                }
                is PressInteraction.Release, is PressInteraction.Cancel -> {
                    if (glow.value < 1f) glow.animateTo(1f, tween(90))
                    glow.animateTo(0f, tween(900, easing = FastOutSlowInEasing))
                }
                else -> Unit
            }
        }
    }
    return glow.value
}

/** Неоновое свечение вокруг круглого элемента. [boost] от 0 до 1 усиливает его. */
fun Modifier.neonGlow(color: Color, baseGlow: Dp, baseAlpha: Float, boost: Float = 0f): Modifier =
    this.drawBehind {
        val alpha = (baseAlpha + (0.95f - baseAlpha) * boost).coerceIn(0f, 1f)
        val extra = baseGlow.toPx() * (1f + 0.7f * boost)
        val radius = size.minDimension / 2f + extra
        val inner = (size.minDimension / 2f) / radius
        drawCircle(
            brush = Brush.radialGradient(
                0f to color.copy(alpha = alpha),
                inner to color.copy(alpha = alpha),
                1f to Color.Transparent,
                center = center,
                radius = radius,
            ),
            radius = radius,
            center = center,
        )
    }

/** Большая круглая неоновая кнопка. Иконка рисуется переданной функцией. */
@Composable
fun NeonButton(
    size: Dp,
    description: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    filled: Boolean = false,
    icon: DrawScope.(Color) -> Unit,
) {
    val interaction = remember { MutableInteractionSource() }
    val k = rememberPressGlow(interaction)

    val borderColor =
        if (filled) lerp(Neon.Light, Color.White, 0.7f * k) else lerp(Neon.Blue, Neon.Light, k)
    val tint = if (filled) Neon.Bg else lerp(Neon.Light, Color.White, 0.7f * k)

    Box(
        modifier = modifier
            .size(size)
            .neonGlow(Neon.Blue, if (filled) 34.dp else 18.dp, if (filled) 0.5f else 0.28f, k)
            .clip(CircleShape)
            .background(if (filled) Neon.Blue else Neon.Surface)
            .drawBehind {
                drawRect(Neon.Light.copy(alpha = (if (filled) 0.4f else 0.25f) * k))
            }
            .border(2.dp, borderColor, CircleShape)
            .clickable(
                interactionSource = interaction,
                indication = null,
                role = Role.Button,
                onClick = onClick,
            )
            .semantics { contentDescription = description },
        contentAlignment = Alignment.Center,
    ) {
        Canvas(Modifier.size(size * 0.38f)) { icon(tint) }
    }
}

/** Широкая кнопка с текстом. */
@Composable
fun NeonPillButton(text: String, onClick: () -> Unit, modifier: Modifier = Modifier) {
    val shape = RoundedCornerShape(36.dp)
    val interaction = remember { MutableInteractionSource() }
    val k = rememberPressGlow(interaction)

    Box(
        modifier = modifier
            .fillMaxWidth()
            .height(72.dp)
            .shadow((16 + 24 * k).dp, shape, ambientColor = Neon.Blue, spotColor = Neon.Blue)
            .clip(shape)
            .background(Neon.Blue)
            .drawBehind { drawRect(Neon.Light.copy(alpha = 0.4f * k)) }
            .border(2.dp, lerp(Neon.Light, Color.White, 0.7f * k), shape)
            .clickable(
                interactionSource = interaction,
                indication = null,
                role = Role.Button,
                onClick = onClick,
            ),
        contentAlignment = Alignment.Center,
    ) {
        Text(text, color = Neon.Bg, fontSize = 20.sp, fontWeight = FontWeight.Bold)
    }
}

/** Вращающийся неоновый диск вместо обложки. */
@Composable
fun NeonDisc(playing: Boolean, modifier: Modifier = Modifier) {
    val angle = remember { Animatable(0f) }
    LaunchedEffect(playing) {
        if (playing) {
            while (true) {
                angle.animateTo(angle.value + 360f, tween(14000, easing = LinearEasing))
            }
        }
    }

    Canvas(modifier) {
        val c = center
        val r = size.minDimension / 2f

        // свечение
        drawCircle(
            brush = Brush.radialGradient(
                0f to Color.Transparent,
                0.72f to Neon.Blue.copy(alpha = 0.38f),
                1f to Color.Transparent,
                center = c,
                radius = r,
            ),
            radius = r,
            center = c,
        )

        // корпус
        drawCircle(Neon.Surface, radius = r * 0.76f, center = c)
        drawCircle(Neon.Blue, radius = r * 0.78f, center = c, style = Stroke(3.dp.toPx()))
        drawCircle(Neon.Dim, radius = r * 0.5f, center = c, style = Stroke(2.dp.toPx()))
        drawCircle(
            Neon.Blue.copy(alpha = 0.5f),
            radius = r * 0.28f,
            center = c,
            style = Stroke(2.dp.toPx()),
        )

        // вращающиеся дуги
        rotate(angle.value % 360f, pivot = c) {
            val r1 = r * 0.64f
            drawArc(
                color = Neon.Light,
                startAngle = 0f,
                sweepAngle = 70f,
                useCenter = false,
                topLeft = Offset(c.x - r1, c.y - r1),
                size = Size(r1 * 2, r1 * 2),
                style = Stroke(6.dp.toPx(), cap = StrokeCap.Round),
            )
            drawArc(
                color = Neon.Blue,
                startAngle = 180f,
                sweepAngle = 70f,
                useCenter = false,
                topLeft = Offset(c.x - r1, c.y - r1),
                size = Size(r1 * 2, r1 * 2),
                style = Stroke(6.dp.toPx(), cap = StrokeCap.Round),
            )
            val r2 = r * 0.4f
            drawArc(
                color = Neon.Light.copy(alpha = 0.7f),
                startAngle = 90f,
                sweepAngle = 50f,
                useCenter = false,
                topLeft = Offset(c.x - r2, c.y - r2),
                size = Size(r2 * 2, r2 * 2),
                style = Stroke(4.dp.toPx(), cap = StrokeCap.Round),
            )
        }

        drawCircle(Neon.Light, radius = r * 0.07f, center = c)
    }
}

/** Ползунок перемотки с временем. */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun NeonSeekBar(
    positionMs: Long,
    durationMs: Long,
    enabled: Boolean,
    onSeek: (Long) -> Unit,
    modifier: Modifier = Modifier,
) {
    var dragging by remember { mutableStateOf(false) }
    var dragValue by remember { mutableFloatStateOf(0f) }
    val duration = max(durationMs, 1L)
    val fraction = (positionMs.toFloat() / duration).coerceIn(0f, 1f)
    val shown = if (dragging) dragValue else fraction

    val colors = SliderDefaults.colors(
        thumbColor = Neon.Light,
        activeTrackColor = Neon.Blue,
        inactiveTrackColor = Neon.Dim,
        disabledThumbColor = Neon.Dim,
        disabledActiveTrackColor = Neon.Dim,
        disabledInactiveTrackColor = Neon.Dim,
    )
    val interaction = remember { MutableInteractionSource() }

    androidx.compose.foundation.layout.Column(modifier) {
        Slider(
            value = shown,
            onValueChange = {
                dragging = true
                dragValue = it
            },
            onValueChangeFinished = {
                onSeek((dragValue * duration).toLong())
                dragging = false
            },
            enabled = enabled,
            colors = colors,
            interactionSource = interaction,
            thumb = {
                SliderDefaults.Thumb(
                    interactionSource = interaction,
                    colors = colors,
                    enabled = enabled,
                    thumbSize = DpSize(26.dp, 26.dp),
                )
            },
            modifier = Modifier
                .fillMaxWidth()
                .height(48.dp),
        )
        androidx.compose.foundation.layout.Row(
            Modifier.fillMaxWidth(),
            horizontalArrangement = androidx.compose.foundation.layout.Arrangement.SpaceBetween,
        ) {
            val shownMs = if (dragging) (dragValue * duration).toLong() else positionMs
            Text(formatTime(shownMs), color = Neon.Muted, fontSize = 14.sp)
            Text(formatTime(durationMs), color = Neon.Muted, fontSize = 14.sp)
        }
    }
}

fun formatTime(ms: Long): String {
    val totalSeconds = (ms / 1000).coerceAtLeast(0)
    return "%d:%02d".format(totalSeconds / 60, totalSeconds % 60)
}
