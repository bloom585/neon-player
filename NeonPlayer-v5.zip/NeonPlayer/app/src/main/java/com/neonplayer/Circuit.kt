package com.neonplayer

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.platform.LocalDensity
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.roundToInt

/**
 * Дорожки микросхемы на фоне. Координаты в пикселях картинки bg_cat.jpg (841 × 1870).
 * Каждая дорожка идёт к котику: сверху вниз в верхней половине, снизу вверх в нижней.
 * Точки сняты по самым ярким линиям картинки.
 */
private const val IMG_W = 841f
private const val IMG_H = 1870f

private val RAW_PATHS = arrayOf(
    // t_center
    floatArrayOf(421.0f, 0.0f, 421.0f, 425.0f),
    // t_335
    floatArrayOf(335.0f, 0.0f, 334.6f, 197.3f, 335.7f, 201.2f, 358.3f, 218.2f, 404.2f, 243.9f),
    // t_365
    floatArrayOf(364.0f, 0.0f, 363.8f, 192.5f, 400.5f, 239.6f),
    // t_258
    floatArrayOf(258.5f, 40.0f, 258.6f, 208.1f, 332.4f, 285.9f, 332.0f, 438.0f),
    // t_116
    floatArrayOf(116.0f, 0.0f, 115.4f, 101.2f, 181.4f, 160.0f, 261.0f, 214.9f, 332.6f, 285.5f, 332.0f, 438.0f),
    // t_38
    floatArrayOf(38.0f, 0.0f, 38.2f, 100.2f, 271.6f, 308.7f, 272.0f, 465.0f),
    // t_right
    floatArrayOf(839.3f, 43.4f, 794.7f, 94.8f, 780.8f, 102.6f, 780.0f, 234.2f, 777.7f, 237.2f, 734.0f, 277.8f, 649.7f, 279.8f, 590.9f, 339.9f, 588.2f, 363.9f, 586.9f, 500.0f),
    // t_r505
    floatArrayOf(618.4f, 1.4f, 594.6f, 29.0f, 505.1f, 116.4f, 504.8f, 250.0f),
    // t_r465
    floatArrayOf(565.8f, 0.8f, 466.3f, 99.7f, 463.4f, 147.7f, 462.9f, 300.0f),
    // t_left
    floatArrayOf(0.0f, 331.0f, 113.1f, 331.8f, 177.4f, 398.8f, 175.4f, 500.0f),
    // b_center
    floatArrayOf(427.1f, 1870.0f, 425.8f, 1685.6f, 420.6f, 1679.7f, 420.1f, 1655.6f, 421.0f, 1375.0f),
    // b_330
    floatArrayOf(218.0f, 1870.0f, 219.3f, 1801.7f, 253.8f, 1737.4f, 253.2f, 1585.8f, 329.8f, 1498.6f, 329.0f, 1350.0f),
    // b_375
    floatArrayOf(335.0f, 1870.0f, 336.3f, 1588.6f, 374.7f, 1514.8f, 376.2f, 1386.2f, 379.4f, 1350.0f),
    // b_left
    floatArrayOf(3.9f, 1829.6f, 58.6f, 1782.4f, 137.1f, 1707.6f, 137.6f, 1587.5f, 276.2f, 1456.5f, 276.0f, 1300.0f),
    // b_left2
    floatArrayOf(0.0f, 1476.0f, 132.8f, 1475.7f, 213.3f, 1404.7f, 213.9f, 1300.0f),
    // b_r1
    floatArrayOf(841.0f, 1496.0f, 740.6f, 1496.2f, 736.7f, 1493.6f, 626.7f, 1387.9f, 624.0f, 1384.2f, 624.0f, 1340.0f),
    // b_r2
    floatArrayOf(621.0f, 1670.0f, 620.1f, 1554.1f, 498.5f, 1429.1f, 496.1f, 1300.0f),
    // b_r3
    floatArrayOf(733.3f, 1596.8f, 551.9f, 1416.6f, 551.2f, 1300.0f),
    // b_r4
    floatArrayOf(841.3f, 1784.7f, 813.1f, 1757.9f, 750.6f, 1755.0f, 654.7f, 1652.4f),
)

private class Trace(val pts: FloatArray) {
    private val count = pts.size / 2
    private val cum = FloatArray(count)
    val length: Float

    init {
        var acc = 0f
        for (i in 1 until count) {
            acc += hypot(pts[2 * i] - pts[2 * i - 2], pts[2 * i + 1] - pts[2 * i - 1])
            cum[i] = acc
        }
        length = acc
    }

    /** Точка на расстоянии [d] от начала дорожки (в пикселях картинки). */
    fun pointAt(d: Float, out: FloatArray) {
        val dist = d.coerceIn(0f, length)
        var lo = 0
        var hi = count - 1
        while (hi - lo > 1) {
            val mid = (lo + hi) ushr 1
            if (cum[mid] <= dist) lo = mid else hi = mid
        }
        val seg = max(cum[hi] - cum[lo], 1e-4f)
        val t = (dist - cum[lo]) / seg
        out[0] = pts[2 * lo] + (pts[2 * hi] - pts[2 * lo]) * t
        out[1] = pts[2 * lo + 1] + (pts[2 * hi + 1] - pts[2 * lo + 1]) * t
    }
}

private const val TAIL_STEPS = 9
private const val TAIL_STEP_PX = 7f   // шаг хвоста в пикселях картинки
private const val FADE_PX = 55f       // плавное появление и исчезновение на концах дорожки
private const val GAP_PX = 150f       // пауза между кругами на одной дорожке

/**
 * Бегущие огни по дорожкам фона, как гирлянда. Движутся плавно и с постоянной скоростью,
 * цвет берут у текущего оттенка плеера. [strength] от 0 до 1 — яркость (в списке треков меньше).
 */
@Composable
fun CircuitElectrons(strength: Float, modifier: Modifier = Modifier) {
    val traces = remember { RAW_PATHS.map { Trace(it) } }
    var time by remember { mutableFloatStateOf(0f) }
    val density = LocalDensity.current.density

    LaunchedEffect(Unit) {
        val start = withFrameNanos { it }
        while (true) {
            val now = withFrameNanos { it }
            time = ((now - start) / 1_000_000_000.0).toFloat()
        }
    }

    Canvas(modifier.fillMaxSize()) {
        if (strength <= 0.01f) return@Canvas
        val scale = max(size.width / IMG_W, size.height / IMG_H)
        val ox = (size.width - IMG_W * scale) / 2f
        val oy = (size.height - IMG_H * scale) / 2f
        val t = time
        val tmp = FloatArray(2)

        traces.forEachIndexed { i, tr ->
            // у каждой дорожки своя скорость и сдвиг, чтобы огни не шли строем
            val speed = 80f + 9f * (i % 5)
            val cycle = tr.length + GAP_PX
            val n = max(1, (tr.length / 230f).roundToInt())
            val shift = (i * 0.37f) % 1f
            for (k in 0 until n) {
                val head = (t * speed + (k + shift) / n * cycle) % cycle
                drawElectron(tr, head, strength, scale, ox, oy, density, tmp)
            }
        }
    }
}

private fun DrawScope.drawElectron(
    tr: Trace,
    head: Float,
    strength: Float,
    scale: Float,
    ox: Float,
    oy: Float,
    density: Float,
    tmp: FloatArray,
) {
    val accent = Neon.Blue
    val light = Neon.Light
    val hot = lerp(light, Color.White, 0.65f)

    for (j in TAIL_STEPS downTo 0) {
        val d = head - j * TAIL_STEP_PX
        if (d < 0f || d > tr.length) continue

        val edge = minOf(d / FADE_PX, (tr.length - d) / FADE_PX).coerceIn(0f, 1f)
        val tail = 1f - j / (TAIL_STEPS + 1f)
        tr.pointAt(d, tmp)
        val x = ox + tmp[0] * scale
        val y = oy + tmp[1] * scale
        // у самого низа экрана огни чуть слабее, чтобы не спорить с кнопками
        val low = ((y / size.height - 0.86f) / 0.14f).coerceIn(0f, 1f)
        val a = strength * edge * (1f - 0.45f * low)
        if (a <= 0.01f) continue
        val c = Offset(x, y)

        if (j == 0) {
            drawCircle(accent.copy(alpha = 0.14f * a), 13f * density, c)
            drawCircle(accent.copy(alpha = 0.30f * a), 7.5f * density, c)
            drawCircle(light.copy(alpha = 0.75f * a), 3.8f * density, c)
            drawCircle(hot.copy(alpha = 0.98f * a), 2.2f * density, c)
        } else {
            val r = (1.2f + 2.2f * tail) * density
            drawCircle(accent.copy(alpha = 0.22f * tail * a), r * 2.6f, c)
            drawCircle(light.copy(alpha = 0.60f * tail * tail * a), r, c)
        }
    }
}
