package com.neonplayer

import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate

// Иконки нарисованы кодом, чтобы не тянуть лишние библиотеки.

private fun DrawScope.softTriangle(path: Path, color: Color) {
    drawPath(path, color)
    drawPath(path, color, style = Stroke(width = size.width * 0.1f, join = StrokeJoin.Round))
}

fun DrawScope.iconPlay(color: Color) {
    val w = size.width
    val h = size.height
    val p = Path().apply {
        moveTo(w * 0.2f, h * 0.02f)
        lineTo(w * 0.96f, h * 0.5f)
        lineTo(w * 0.2f, h * 0.98f)
        close()
    }
    softTriangle(p, color)
}

fun DrawScope.iconPause(color: Color) {
    val w = size.width
    val h = size.height
    val bar = Size(w * 0.28f, h)
    val corner = CornerRadius(w * 0.07f)
    drawRoundRect(color, Offset(w * 0.1f, 0f), bar, corner)
    drawRoundRect(color, Offset(w * 0.62f, 0f), bar, corner)
}

fun DrawScope.iconNext(color: Color) {
    val w = size.width
    val h = size.height
    val p = Path().apply {
        moveTo(0f, h * 0.02f)
        lineTo(w * 0.76f, h * 0.5f)
        lineTo(0f, h * 0.98f)
        close()
    }
    softTriangle(p, color)
    drawRoundRect(color, Offset(w * 0.86f, 0f), Size(w * 0.14f, h), CornerRadius(w * 0.05f))
}

fun DrawScope.iconPrevious(color: Color) {
    val w = size.width
    val h = size.height
    val p = Path().apply {
        moveTo(w, h * 0.02f)
        lineTo(w * 0.24f, h * 0.5f)
        lineTo(w, h * 0.98f)
        close()
    }
    softTriangle(p, color)
    drawRoundRect(color, Offset(0f, 0f), Size(w * 0.14f, h), CornerRadius(w * 0.05f))
}

fun DrawScope.iconList(color: Color) {
    val w = size.width
    val h = size.height
    val barH = h * 0.16f
    val corner = CornerRadius(barH / 2f)
    drawRoundRect(color, Offset(0f, h * 0.06f), Size(w, barH), corner)
    drawRoundRect(color, Offset(0f, h * 0.42f), Size(w, barH), corner)
    drawRoundRect(color, Offset(0f, h * 0.78f), Size(w * 0.7f, barH), corner)
}

fun DrawScope.iconClose(color: Color) {
    val w = size.width
    val h = size.height
    val stroke = w * 0.16f
    drawLine(color, Offset(w * 0.08f, h * 0.08f), Offset(w * 0.92f, h * 0.92f), stroke, StrokeCap.Round)
    drawLine(color, Offset(w * 0.92f, h * 0.08f), Offset(w * 0.08f, h * 0.92f), stroke, StrokeCap.Round)
}

/** Две стрелки по кругу. Если [one] = true, посередине рисуется «1». */
fun DrawScope.iconRepeat(color: Color, one: Boolean) {
    val w = size.width
    val h = size.height
    val stroke = Stroke(width = w * 0.11f, cap = StrokeCap.Round, join = StrokeJoin.Round)

    val line = Path().apply {
        moveTo(w * 0.1f, h * 0.62f)
        lineTo(w * 0.1f, h * 0.34f)
        lineTo(w * 0.22f, h * 0.22f)
        lineTo(w * 0.74f, h * 0.22f)
    }
    val head = Path().apply {
        moveTo(w * 0.72f, 0f)
        lineTo(w, h * 0.22f)
        lineTo(w * 0.72f, h * 0.44f)
        close()
    }

    drawPath(line, color, style = stroke)
    drawPath(head, color)
    rotate(180f, pivot = center) {
        drawPath(line, color, style = stroke)
        drawPath(head, color)
    }

    if (one) {
        val digit = Path().apply {
            moveTo(w * 0.42f, h * 0.42f)
            lineTo(w * 0.52f, h * 0.35f)
            lineTo(w * 0.52f, h * 0.65f)
        }
        drawPath(
            digit,
            color,
            style = Stroke(width = w * 0.09f, cap = StrokeCap.Round, join = StrokeJoin.Round),
        )
    }
}

/** Три ровные черты — ручка для перетаскивания. */
fun DrawScope.iconGrip(color: Color) {
    val w = size.width
    val h = size.height
    val barH = h * 0.16f
    val corner = CornerRadius(barH / 2f)
    for (i in 0..2) {
        drawRoundRect(color, Offset(0f, i * (h - barH) / 2f), Size(w, barH), corner)
    }
}

/** Три ползунка с бегунками: настройки внешнего вида. */
fun DrawScope.iconTune(color: Color) {
    val w = size.width
    val h = size.height
    val stroke = h * 0.12f
    val knob = h * 0.15f
    val rows = floatArrayOf(0.12f, 0.5f, 0.88f)
    val knobAt = floatArrayOf(0.7f, 0.3f, 0.6f)
    for (i in rows.indices) {
        val y = h * rows[i]
        val x = w * knobAt[i]
        val gap = knob + stroke * 0.9f
        drawLine(color, Offset(0f, y), Offset(x - gap, y), stroke, StrokeCap.Round)
        drawLine(color, Offset(x + gap, y), Offset(w, y), stroke, StrokeCap.Round)
        drawCircle(color, radius = knob, center = Offset(x, y))
    }
}

/** Две пересекающиеся стрелки: случайный порядок и перемешивание. */
fun DrawScope.iconShuffle(color: Color) {
    val w = size.width
    val h = size.height
    val stroke = Stroke(width = w * 0.11f, cap = StrokeCap.Round, join = StrokeJoin.Round)

    val down = Path().apply {
        moveTo(0f, h * 0.22f)
        lineTo(w * 0.3f, h * 0.22f)
        lineTo(w * 0.7f, h * 0.78f)
        lineTo(w * 0.78f, h * 0.78f)
    }
    val up = Path().apply {
        moveTo(0f, h * 0.78f)
        lineTo(w * 0.3f, h * 0.78f)
        lineTo(w * 0.7f, h * 0.22f)
        lineTo(w * 0.78f, h * 0.22f)
    }
    drawPath(down, color, style = stroke)
    drawPath(up, color, style = stroke)

    val headTop = Path().apply {
        moveTo(w * 0.76f, 0f)
        lineTo(w, h * 0.22f)
        lineTo(w * 0.76f, h * 0.44f)
        close()
    }
    val headBottom = Path().apply {
        moveTo(w * 0.76f, h * 0.56f)
        lineTo(w, h * 0.78f)
        lineTo(w * 0.76f, h)
        close()
    }
    drawPath(headTop, color)
    drawPath(headBottom, color)
}

/**
 * Динамик с волнами. [level] от 0 до 1: чем громче, тем больше волн,
 * а при нуле вместо волн крестик.
 */
fun DrawScope.iconSpeaker(color: Color, level: Float) {
    val w = size.width
    val h = size.height

    val body = Path().apply {
        moveTo(0f, h * 0.36f)
        lineTo(w * 0.16f, h * 0.36f)
        lineTo(w * 0.38f, h * 0.14f)
        lineTo(w * 0.38f, h * 0.86f)
        lineTo(w * 0.16f, h * 0.64f)
        lineTo(0f, h * 0.64f)
        close()
    }
    drawPath(body, color)
    drawPath(body, color, style = Stroke(width = w * 0.07f, join = StrokeJoin.Round))

    val line = w * 0.09f
    if (level <= 0.001f) {
        drawLine(color, Offset(w * 0.6f, h * 0.34f), Offset(w * 0.94f, h * 0.66f), line, StrokeCap.Round)
        drawLine(color, Offset(w * 0.94f, h * 0.34f), Offset(w * 0.6f, h * 0.66f), line, StrokeCap.Round)
        return
    }

    val waves = when {
        level < 0.34f -> 1
        level < 0.67f -> 2
        else -> 3
    }
    val cx = w * 0.36f
    val cy = h * 0.5f
    for (i in 0 until waves) {
        val r = w * (0.22f + 0.16f * i)
        drawArc(
            color = color,
            startAngle = -42f,
            sweepAngle = 84f,
            useCenter = false,
            topLeft = Offset(cx - r, cy - r),
            size = Size(r * 2f, r * 2f),
            style = Stroke(width = line, cap = StrokeCap.Round),
        )
    }
}
