package com.neonplayer

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LifecycleEventEffect

class MainActivity : ComponentActivity() {

    private val vm: PlayerViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // Тема и цвет, выбранные в прошлый раз, нужны до первой отрисовки
        Neon.restore(this)
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT),
        )
        setContent {
            NeonTheme {
                NeonPlayerApp(vm)
            }
        }
    }
}

private const val SCREEN_PLAYER = 0
private const val SCREEN_LIST = 1
private const val SCREEN_SETTINGS = 2

private val AUDIO_PERMISSION =
    if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_AUDIO
    else Manifest.permission.READ_EXTERNAL_STORAGE

@Composable
fun NeonPlayerApp(vm: PlayerViewModel) {
    val context = LocalContext.current

    fun hasAudioPermission() =
        ContextCompat.checkSelfPermission(context, AUDIO_PERMISSION) ==
            PackageManager.PERMISSION_GRANTED

    var granted by remember { mutableStateOf(hasAudioPermission()) }
    var denied by remember { mutableStateOf(false) }
    var screen by rememberSaveable { mutableStateOf(SCREEN_PLAYER) }

    val notificationLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission(),
    ) { /* уведомление с управлением просто не покажется, если отказать */ }

    val audioLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission(),
    ) { ok ->
        granted = ok
        denied = !ok
    }

    // Вернулись из системных настроек — проверяем доступ ещё раз
    LifecycleEventEffect(Lifecycle.Event.ON_RESUME) {
        granted = hasAudioPermission()
    }

    LaunchedEffect(Unit) {
        if (!granted) audioLauncher.launch(AUDIO_PERMISSION)
    }

    LaunchedEffect(granted) {
        if (granted) {
            vm.loadTracks()
            if (Build.VERSION.SDK_INT >= 33 &&
                ContextCompat.checkSelfPermission(
                    context,
                    Manifest.permission.POST_NOTIFICATIONS,
                ) != PackageManager.PERMISSION_GRANTED
            ) {
                notificationLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
            }
        }
    }

    BackHandler(enabled = screen != SCREEN_PLAYER) { screen = SCREEN_PLAYER }

    Box(Modifier.fillMaxSize()) {
        // Фон на весь экран, под системными панелями. Отступы от панелей делает каждый экран сам
        NeonBackground(
            dim = when {
                !granted -> 1f
                screen == SCREEN_LIST -> 1f
                // в настройках фон почти открыт, чтобы было видно, как меняются цвет и тема
                screen == SCREEN_SETTINGS -> 0.3f
                else -> 0f
            },
        )

        when {
            !granted -> PermissionScreen(
                buttonText = if (denied) "Открыть настройки" else "Разрешить",
                onRequest = {
                    if (denied) {
                        context.startActivity(
                            Intent(
                                Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                                Uri.fromParts("package", context.packageName, null),
                            ),
                        )
                    } else {
                        audioLauncher.launch(AUDIO_PERMISSION)
                    }
                },
            )

            screen == SCREEN_LIST -> TrackListScreen(vm = vm, onBack = { screen = SCREEN_PLAYER })

            screen == SCREEN_SETTINGS -> SettingsScreen(onBack = { screen = SCREEN_PLAYER })

            else -> PlayerScreen(
                vm = vm,
                onOpenList = { screen = SCREEN_LIST },
                onOpenSettings = { screen = SCREEN_SETTINGS },
            )
        }
    }
}
