package com.neonplayer

import android.content.Context
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.graphics.ColorMatrix
import androidx.compose.ui.graphics.lerp

/** Оттенок неона по умолчанию: тот самый синий. */
const val DEFAULT_HUE = 212f

/**
 * Одна тема оформления. Цвет неона у всех тем один и тот же, его выбирает ползунок,
 * а тема решает, какими будут фон, кнопки и картинка с микросхемой.
 *
 * Поля вида xxxS и xxxV — насыщенность и яркость в HSV, оттенок берётся у ползунка.
 */
class NeonThemeSpec(
    val name: String,
    val bgS: Float,
    val bgV: Float,
    val surfaceS: Float,
    val surfaceV: Float,
    val dimS: Float,
    val dimV: Float,
    val mutedS: Float,
    /** Яркость картинки с котиком: 1 — как есть, меньше — темнее. */
    val imageBright: Float,
    /** Насколько обесцветить картинку: 0 — цвет неона, 1 — серебристая. */
    val imageGray: Float,
    /** Как сильно затемнять верх и низ экрана: 1 — как обычно, меньше — светлее. */
    val scrim: Float,
)

val NEON_THEMES = listOf(
    NeonThemeSpec("Неон", 0.69f, 0.05f, 0.74f, 0.15f, 0.65f, 0.25f, 0.38f, 1.00f, 0.00f, 1.00f),
    NeonThemeSpec("Ночь", 0.60f, 0.00f, 0.70f, 0.07f, 0.65f, 0.17f, 0.34f, 0.55f, 0.00f, 1.00f),
    NeonThemeSpec("Сумерки", 0.60f, 0.13f, 0.60f, 0.22f, 0.55f, 0.33f, 0.45f, 0.95f, 0.00f, 0.55f),
    NeonThemeSpec("Призрак", 0.22f, 0.05f, 0.28f, 0.13f, 0.28f, 0.24f, 0.16f, 0.90f, 0.78f, 1.00f),
)

class NeonPalette(
    val bg: Color,
    val surface: Color,
    val dim: Color,
    val blue: Color,
    val light: Color,
    val text: Color,
    val muted: Color,
)

private fun hsv(h: Float, s: Float, v: Float): Color =
    Color.hsv(((h % 360f) + 360f) % 360f, s.coerceIn(0f, 1f), v.coerceIn(0f, 1f))

fun buildPalette(themeId: Int, hue: Float): NeonPalette {
    val t = NEON_THEMES[themeId.coerceIn(0, NEON_THEMES.lastIndex)]
    return NeonPalette(
        bg = hsv(hue, t.bgS, t.bgV),
        surface = hsv(hue, t.surfaceS, t.surfaceV),
        dim = hsv(hue, t.dimS, t.dimV),
        blue = hsv(hue, 0.88f, 1f),
        light = hsv(hue - 13f, 0.62f, 1f),
        text = hsv(hue, 0.07f, 1f),
        muted = hsv(hue, t.mutedS, 0.80f),
    )
}

/**
 * Текущие цвета плеера. Это живое состояние: любой экран, который читает Neon.Blue и другие цвета,
 * сам перерисуется, когда ползунок или тема меняются.
 */
object Neon {
    var themeId by mutableIntStateOf(0)
    var hue by mutableFloatStateOf(DEFAULT_HUE)

    private val palette by derivedStateOf { buildPalette(themeId, hue) }

    val spec: NeonThemeSpec
        get() = NEON_THEMES[themeId.coerceIn(0, NEON_THEMES.lastIndex)]

    val Bg: Color get() = palette.bg
    val Surface: Color get() = palette.surface
    val Dim: Color get() = palette.dim
    val Blue: Color get() = palette.blue
    val Light: Color get() = palette.light
    val Text: Color get() = palette.text
    val Muted: Color get() = palette.muted

    private const val PREFS = "neon_player"

    /** Читает сохранённые тему и цвет. Вызывать до setContent. */
    fun restore(context: Context) {
        val p = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        themeId = p.getInt("theme", 0).coerceIn(0, NEON_THEMES.lastIndex)
        hue = p.getFloat("hue", DEFAULT_HUE).coerceIn(0f, 360f)
    }

    fun save(context: Context) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .putInt("theme", themeId)
            .putFloat("hue", hue)
            .apply()
    }
}

/**
 * Перекрашивает картинку фона в цвет неона. Яркость линий берётся из синего канала картинки,
 * а светлые ядра линий (зелёный канал) чуть осветляют цвет, как в оригинале.
 */
fun neonImageFilter(accent: Color, spec: NeonThemeSpec): ColorFilter {
    val silver = Color(0.78f, 0.84f, 0.95f)
    val c = lerp(accent, silver, spec.imageGray)
    val br = spec.imageBright

    fun fromGreen(ch: Float) = br * (ch * 0.08f + (1f - ch) * 0.20f)
    fun fromBlue(ch: Float) = br * ch * 0.92f

    return ColorFilter.colorMatrix(
        ColorMatrix(
            floatArrayOf(
                0f, fromGreen(c.red), fromBlue(c.red), 0f, 0f,
                0f, fromGreen(c.green), fromBlue(c.green), 0f, 0f,
                0f, fromGreen(c.blue), fromBlue(c.blue), 0f, 0f,
                0f, 0f, 0f, 1f, 0f,
            ),
        ),
    )
}
