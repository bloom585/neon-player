package com.neonplayer

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.FiniteAnimationSpec
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.VisibilityThreshold
import androidx.compose.animation.core.animate
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.scrollBy
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.safeDrawingPadding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.coerceAtLeast
import androidx.compose.ui.unit.coerceIn
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.zIndex
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlin.math.PI
import kotlin.math.max
import kotlin.math.sin

// ---------------------------------------------------------------------------------------------
// Экран плеера
// ---------------------------------------------------------------------------------------------

@Composable
fun PlayerScreen(vm: PlayerViewModel, onOpenList: () -> Unit, onOpenSettings: () -> Unit) {
    val config = LocalConfiguration.current
    if (config.screenWidthDp > config.screenHeightDp) {
        PlayerLandscape(vm, onOpenList, onOpenSettings)
    } else {
        PlayerPortrait(vm, onOpenList, onOpenSettings)
    }
}

/** Вертикально: название сверху, диск в центре, внизу четыре кнопки, шкала и управление. */
@Composable
private fun PlayerPortrait(vm: PlayerViewModel, onOpenList: () -> Unit, onOpenSettings: () -> Unit) {
    val hasTrack = vm.currentIndex >= 0
    val bottomInset = WindowInsets.navigationBars.asPaddingValues().calculateBottomPadding()

    BoxWithConstraints(Modifier.fillMaxSize()) {
        // На невысоких экранах кнопки чуть уменьшаются, чтобы хватило места диску
        val s = ((maxHeight.value - 640f) / 260f).coerceIn(0.85f, 1f)
        val mini = 72.dp * s
        val side = 84.dp * s
        val play = 128.dp * s

        // Нижняя часть экрана: четыре кнопки, шкала, управление и отступы
        val stackH = play + mini + 92.dp
        // Диск стоит по центру экрана: там же у котика на фоне голова. Свечение диска
        // выходит за его край на 12%, и всё вместе не должно доставать до верхнего ряда кнопок.
        val discSize = minOf(
            maxWidth * 0.7f,
            300.dp,
            (maxHeight / 2 - bottomInset - stackH - 6.dp) * 2f / 1.12f,
        ).coerceAtLeast(120.dp)

        NeonDisc(
            playing = vm.isPlaying,
            modifier = Modifier
                .align(Alignment.Center)
                .size(discSize),
        )

        Column(
            modifier = Modifier
                .fillMaxSize()
                .systemBarsPadding()
                .padding(horizontal = 24.dp, vertical = 12.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Spacer(Modifier.height(16.dp))

            // Название и исполнитель сверху, чтобы не наезжать на котика в центре
            TrackTitle(
                vm = vm,
                hasTrack = hasTrack,
                titleSize = 24.sp,
                artistSize = 16.sp,
                titleLines = 2,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(96.dp),
            )

            Spacer(Modifier.weight(1f))

            // Четыре кнопки стоят прямо над шкалой, чтобы дотягиваться большим пальцем
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically,
            ) {
                RepeatButton(vm, mini)
                ShuffleButton(vm, mini)
                SettingsButton(onOpenSettings, mini)
                ListButton(onOpenList, mini)
            }

            Spacer(Modifier.height(2.dp))

            NeonSeekBar(
                positionMs = vm.positionMs,
                durationMs = vm.durationMs,
                enabled = hasTrack,
                onSeek = vm::seekTo,
                modifier = Modifier.fillMaxWidth(),
            )

            Spacer(Modifier.height(4.dp))

            TransportRow(vm, side, play, Modifier.fillMaxWidth())

            Spacer(Modifier.height(8.dp))
        }
    }
}

/**
 * Горизонтально: слева четыре кнопки, в центре название, диск и шкала, справа управление.
 * Так кнопки не наезжают друг на друга и на диск, а большие пальцы лежат на краях.
 */
@Composable
private fun PlayerLandscape(vm: PlayerViewModel, onOpenList: () -> Unit, onOpenSettings: () -> Unit) {
    val hasTrack = vm.currentIndex >= 0
    val insets = WindowInsets.safeDrawing.asPaddingValues()

    BoxWithConstraints(Modifier.fillMaxSize()) {
        val top = insets.calculateTopPadding()
        val bottom = insets.calculateBottomPadding()

        val centerW = (maxWidth * 0.40f).coerceIn(260.dp, 420.dp)
        val zoneW = (maxWidth - 32.dp - centerW) / 2f
        // Размер кнопок подстраивается и под ширину боковых зон, и под высоту экрана
        val k = minOf((zoneW.value / 250f).coerceIn(0.7f, 1f), (maxHeight.value / 400f).coerceIn(0.75f, 1f))
        val mini = 68.dp * k
        val side = 72.dp * k
        val play = 100.dp * k
        val gap = 14.dp * k

        val titleH = 56.dp
        val seekH = 70.dp
        // Диск между названием и шкалой, по центру экрана
        val half = maxHeight / 2 - maxOf(top + 8.dp + titleH, bottom + 8.dp + seekH) - 4.dp
        val discSize = (half * 2f / 1.12f).coerceIn(110.dp, 260.dp)

        NeonDisc(
            playing = vm.isPlaying,
            modifier = Modifier
                .align(Alignment.Center)
                .size(discSize),
        )

        Row(
            modifier = Modifier
                .fillMaxSize()
                .safeDrawingPadding()
                .padding(horizontal = 16.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxHeight(),
                contentAlignment = Alignment.Center,
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(gap)) {
                    Row(horizontalArrangement = Arrangement.spacedBy(gap)) {
                        RepeatButton(vm, mini)
                        ShuffleButton(vm, mini)
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(gap)) {
                        SettingsButton(onOpenSettings, mini)
                        ListButton(onOpenList, mini)
                    }
                }
            }

            Column(
                modifier = Modifier
                    .width(centerW)
                    .fillMaxHeight(),
                horizontalAlignment = Alignment.CenterHorizontally,
            ) {
                TrackTitle(
                    vm = vm,
                    hasTrack = hasTrack,
                    titleSize = 20.sp,
                    artistSize = 14.sp,
                    titleLines = 1,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(titleH),
                )
                Spacer(Modifier.weight(1f))
                NeonSeekBar(
                    positionMs = vm.positionMs,
                    durationMs = vm.durationMs,
                    enabled = hasTrack,
                    onSeek = vm::seekTo,
                    modifier = Modifier.fillMaxWidth(),
                )
            }

            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxHeight(),
                contentAlignment = Alignment.Center,
            ) {
                TransportRow(vm, side, play, Modifier.fillMaxWidth())
            }
        }
    }
}

@Composable
private fun TrackTitle(
    vm: PlayerViewModel,
    hasTrack: Boolean,
    titleSize: androidx.compose.ui.unit.TextUnit,
    artistSize: androidx.compose.ui.unit.TextUnit,
    titleLines: Int,
    modifier: Modifier = Modifier,
) {
    Column(
        modifier = modifier,
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
    ) {
        Text(
            text = if (hasTrack) vm.title else "Выберите трек",
            color = Neon.Text,
            fontSize = titleSize,
            fontWeight = FontWeight.Bold,
            maxLines = titleLines,
            overflow = TextOverflow.Ellipsis,
            textAlign = TextAlign.Center,
            modifier = Modifier.fillMaxWidth(),
        )
        Spacer(Modifier.height(4.dp))
        Text(
            text = if (hasTrack) vm.artist else " ",
            color = Neon.Muted,
            fontSize = artistSize,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            textAlign = TextAlign.Center,
            modifier = Modifier.fillMaxWidth(),
        )
    }
}

@Composable
private fun RepeatButton(vm: PlayerViewModel, size: Dp) {
    NeonButton(
        size = size,
        description = if (vm.repeatOne) "Повтор одной песни включён" else "Повторять одну песню",
        onClick = vm::toggleRepeatOne,
        filled = vm.repeatOne,
    ) { iconRepeat(it, vm.repeatOne) }
}

@Composable
private fun ShuffleButton(vm: PlayerViewModel, size: Dp) {
    NeonButton(
        size = size,
        description = if (vm.shuffleOn) "Случайный порядок включён" else "Слушать в случайном порядке",
        onClick = vm::toggleShuffle,
        filled = vm.shuffleOn,
    ) { iconShuffle(it) }
}

@Composable
private fun SettingsButton(onClick: () -> Unit, size: Dp) {
    NeonButton(
        size = size,
        description = "Оформление: цвет и тема",
        onClick = onClick,
    ) { iconTune(it) }
}

@Composable
private fun ListButton(onClick: () -> Unit, size: Dp) {
    NeonButton(
        size = size,
        description = "Список треков",
        onClick = onClick,
    ) { iconList(it) }
}

@Composable
private fun TransportRow(vm: PlayerViewModel, side: Dp, play: Dp, modifier: Modifier = Modifier) {
    Row(
        modifier = modifier,
        horizontalArrangement = Arrangement.SpaceEvenly,
        verticalAlignment = Alignment.CenterVertically,
    ) {
        // zIndex у боковых кнопок, чтобы волны от play шли позади них
        NeonButton(
            size = side,
            description = "Предыдущий трек",
            onClick = vm::previous,
            modifier = Modifier.zIndex(1f),
        ) { iconPrevious(it) }

        NeonButton(
            size = play,
            description = if (vm.isPlaying) "Пауза" else "Играть",
            onClick = vm::togglePlay,
            filled = true,
            pulse = vm.isPlaying,
        ) { if (vm.isPlaying) iconPause(it) else iconPlay(it) }

        NeonButton(
            size = side,
            description = "Следующий трек",
            onClick = vm::next,
            modifier = Modifier.zIndex(1f),
        ) { iconNext(it) }
    }
}

// ---------------------------------------------------------------------------------------------
// Библиотека песен
// ---------------------------------------------------------------------------------------------

/**
 * Насколько приподнята карточка во время перемешивания: 0 в покое, 1 на пике.
 * [wave] идёт от 0 до 1; у соседних карточек небольшой сдвиг по времени, так что движение
 * идёт волной, а не всем списком сразу.
 */
private fun shuffleLift(wave: Float, index: Int): Float {
    val phase = (index % 7) / 7f * 0.25f
    val t = ((wave - phase) / 0.75f).coerceIn(0f, 1f)
    return sin(PI.toFloat() * t)
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun TrackListScreen(vm: PlayerViewModel, onBack: () -> Unit) {
    val listState = rememberLazyListState()
    val scope = rememberCoroutineScope()

    var draggedId by remember { mutableStateOf<String?>(null) }
    var fingerDown by remember { mutableStateOf(false) }

    // Где сейчас верх перетаскиваемой карточки в окне списка. Палец двигает именно это значение,
    // и оно ограничено окном списка: нельзя «увести» карточку за верх или низ.
    var visualTop by remember { mutableFloatStateOf(0f) }
    var settleJob by remember { mutableStateOf<Job?>(null) }

    // Меню громкости одной песни
    var sheetId by remember { mutableStateOf("") }
    var sheetOpen by remember { mutableStateOf(false) }

    // Перемешивание: wave ведёт карточки, spin крутит значок на кнопке
    var shuffling by remember { mutableStateOf(false) }
    val wave = remember { Animatable(0f) }
    val spin = remember { Animatable(0f) }

    val density = LocalDensity.current
    val edgePx = with(density) { 72.dp.toPx() }
    val scrollStepPx = with(density) { 9.dp.toPx() }

    fun checkSwap() {
        val id = draggedId ?: return
        val info = listState.layoutInfo
        val visible = info.visibleItemsInfo
        val dragged = visible.firstOrNull { it.key == id } ?: return
        val from = vm.tracks.indexOfFirst { it.mediaItem.mediaId == id }
        // Список ещё не перерисовался после прошлой перестановки — подождём
        if (from < 0 || dragged.index != from) return

        val center = visualTop + dragged.size / 2f
        val target = visible.firstOrNull {
            it.key != id && center >= it.offset && center <= it.offset + it.size
        } ?: return
        if (target.index !in vm.tracks.indices) return

        // Запоминаем, что сейчас в верхней части окна, и после перестановки возвращаем так же.
        // Иначе список «приклеивается» к бывшему первому треку, и перетаскиваемый уезжает за верх экрана.
        val firstIndex = listState.firstVisibleItemIndex
        val firstOffset = listState.firstVisibleItemScrollOffset
        vm.moveTrack(from, target.index)
        listState.requestScrollToItem(firstIndex, firstOffset)
    }

    fun startDrag(id: String) {
        settleJob?.cancel()
        val item = listState.layoutInfo.visibleItemsInfo.firstOrNull { it.key == id } ?: return
        draggedId = id
        visualTop = item.offset.toFloat()
        fingerDown = true
    }

    fun dragBy(dy: Float) {
        val id = draggedId ?: return
        val info = listState.layoutInfo
        val itemSize = info.visibleItemsInfo.firstOrNull { it.key == id }?.size ?: 0
        val low = info.viewportStartOffset.toFloat()
        val high = max(low, (info.viewportEndOffset - itemSize).toFloat())
        visualTop = (visualTop + dy).coerceIn(low, high)
        checkSwap()
    }

    fun endDrag() {
        fingerDown = false
        vm.saveOrder()
        val id = draggedId
        settleJob = scope.launch {
            val from = visualTop
            animate(0f, 1f, animationSpec = tween(180)) { f, _ ->
                val offset = listState.layoutInfo.visibleItemsInfo
                    .firstOrNull { it.key == id }?.offset
                if (offset != null) visualTop = from + (offset - from) * f
            }
            draggedId = null
        }
    }

    /**
     * Красивое перемешивание в три такта: карточки приподнимаются и чуть качаются волной,
     * на пике порядок меняется, и они плавно разлетаются по новым местам и опускаются.
     */
    fun shuffleAll() {
        if (shuffling || vm.tracks.size < 2) return
        settleJob?.cancel()
        draggedId = null
        fingerDown = false
        shuffling = true
        scope.launch {
            launch {
                spin.snapTo(0f)
                spin.animateTo(360f, tween(1500, easing = FastOutSlowInEasing))
                spin.snapTo(0f)
            }
            wave.snapTo(0f)
            wave.animateTo(0.5f, tween(420, easing = FastOutSlowInEasing))
            vm.shuffleTracks()
            wave.animateTo(1f, tween(1000, easing = FastOutSlowInEasing))
            wave.snapTo(0f)
            shuffling = false
        }
    }

    // Пока палец держит трек у края, список сам едет вверх или вниз, даже если палец не двигается
    LaunchedEffect(fingerDown) {
        if (!fingerDown) return@LaunchedEffect
        while (true) {
            val info = listState.layoutInfo
            val dragged = info.visibleItemsInfo.firstOrNull { it.key == draggedId }
            if (dragged != null) {
                val top = visualTop
                val bottom = top + dragged.size
                val step = when {
                    top < info.viewportStartOffset + edgePx -> -scrollStepPx
                    bottom > info.viewportEndOffset - edgePx -> scrollStepPx
                    else -> 0f
                }
                if (step != 0f) {
                    listState.scrollBy(step)
                    checkSwap()
                }
            }
            delay(16)
        }
    }

    // «Назад» сначала закрывает меню громкости, а не весь список
    BackHandler(enabled = sheetOpen) {
        vm.saveVolumes()
        sheetOpen = false
    }

    // Во время перемешивания карточки плывут медленно и плавно, в остальное время — как обычно
    val placementSpec: FiniteAnimationSpec<IntOffset> = if (shuffling) {
        tween(750, easing = FastOutSlowInEasing)
    } else {
        spring(stiffness = Spring.StiffnessMediumLow, visibilityThreshold = IntOffset.VisibilityThreshold)
    }

    BoxWithConstraints(Modifier.fillMaxSize()) {
        // В горизонтальном положении места по высоте мало, поэтому всё чуть компактнее
        val compact = maxHeight < 480.dp
        val bottomSize = if (compact) 60.dp else 72.dp
        val rowHeight = if (compact) 68.dp else 80.dp

        Column(
            modifier = Modifier
                .fillMaxSize()
                .safeDrawingPadding()
                .padding(horizontal = 24.dp, vertical = 12.dp),
        ) {
            Text(
                "Треки",
                color = Neon.Text,
                fontSize = if (compact) 22.sp else 28.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(top = 8.dp),
            )

            if (vm.tracks.isEmpty()) {
                Box(
                    Modifier
                        .weight(1f)
                        .fillMaxWidth(),
                    contentAlignment = Alignment.Center,
                ) {
                    Text("Музыка не найдена", color = Neon.Muted, fontSize = 18.sp)
                }
            } else {
                LazyColumn(
                    state = listState,
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth(),
                    contentPadding = PaddingValues(top = 16.dp, bottom = 16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                ) {
                    itemsIndexed(vm.tracks, key = { _, t -> t.mediaItem.mediaId }) { index, track ->
                        val id = track.mediaItem.mediaId
                        val isDragged = id == draggedId

                        TrackRow(
                            track = track,
                            current = id == vm.currentMediaId,
                            dragged = isDragged,
                            volume = vm.volumeOf(id),
                            rowHeight = rowHeight,
                            swing = if (index % 2 == 0) 1f else -1f,
                            lift = { shuffleLift(wave.value, index) },
                            modifier = if (isDragged) {
                                Modifier
                                    .zIndex(1f)
                                    .graphicsLayer {
                                        // Карточка рисуется ровно там, где палец, даже если её место в списке сменилось
                                        val offset = listState.layoutInfo.visibleItemsInfo
                                            .firstOrNull { it.key == id }?.offset ?: 0
                                        translationY = visualTop - offset
                                        scaleX = 1.03f
                                        scaleY = 1.03f
                                    }
                            } else {
                                Modifier.animateItem(placementSpec = placementSpec)
                            },
                            onClick = {
                                vm.play(vm.tracks.indexOfFirst { it.mediaItem.mediaId == id })
                                onBack()
                            },
                            onVolume = {
                                sheetId = id
                                sheetOpen = true
                            },
                            onDragStart = { startDrag(id) },
                            onDrag = { dy -> dragBy(dy) },
                            onDragEnd = { endDrag() },
                        )
                    }
                }
            }

            // Внизу: перемешать все песни и кнопка закрытия в правом нижнем углу
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                NeonPillButton(
                    text = "Перемешать",
                    onClick = { shuffleAll() },
                    height = bottomSize,
                    icon = { iconShuffle(it) },
                    iconRotation = spin.value,
                    modifier = Modifier.weight(1f),
                )
                Spacer(Modifier.width(16.dp))
                NeonButton(
                    size = bottomSize,
                    description = "Закрыть список",
                    onClick = onBack,
                ) { iconClose(it) }
            }
        }

        val sheetTrack = vm.tracks.firstOrNull { it.mediaItem.mediaId == sheetId }
        AnimatedVisibility(
            visible = sheetOpen && sheetTrack != null,
            enter = fadeIn(tween(220)) + slideInVertically(tween(280)) { it / 8 },
            exit = fadeOut(tween(200)) + slideOutVertically(tween(240)) { it / 8 },
        ) {
            if (sheetTrack != null) {
                VolumeSheet(
                    trackTitle = sheetTrack.title,
                    trackArtist = sheetTrack.artist,
                    volume = vm.volumeOf(sheetId),
                    onChange = { vm.setVolume(sheetId, it) },
                    onDone = { vm.saveVolumes() },
                    onClose = {
                        vm.saveVolumes()
                        sheetOpen = false
                    },
                )
            }
        }
    }
}

@Composable
private fun TrackRow(
    track: Track,
    current: Boolean,
    dragged: Boolean,
    volume: Float,
    rowHeight: Dp,
    swing: Float,
    lift: () -> Float,
    modifier: Modifier,
    onClick: () -> Unit,
    onVolume: () -> Unit,
    onDragStart: () -> Unit,
    onDrag: (Float) -> Unit,
    onDragEnd: () -> Unit,
) {
    val shape = RoundedCornerShape(22.dp)
    val interaction = remember { MutableInteractionSource() }
    val press = rememberPressGlow(interaction)
    val hot = max(press, if (dragged) 1f else 0f)
    val borderColor = lerp(if (current) Neon.Blue else Neon.Dim, Neon.Light, hot)

    val startCb by rememberUpdatedState(onDragStart)
    val dragCb by rememberUpdatedState(onDrag)
    val endCb by rememberUpdatedState(onDragEnd)

    Row(
        modifier = modifier
            .fillMaxWidth()
            .height(rowHeight)
            .graphicsLayer {
                // Во время перемешивания карточка приподнимается: чуть меньше, прозрачнее и в наклоне
                val l = lift()
                if (l > 0f) {
                    val s = 1f - 0.06f * l
                    scaleX = s
                    scaleY = s
                    alpha = 1f - 0.4f * l
                    rotationZ = swing * 2.2f * l
                    translationX = swing * 12.dp.toPx() * l
                }
            }
            .clip(shape)
            .background(Neon.Surface)
            .drawBehind { drawRect(Neon.Blue.copy(alpha = 0.18f * hot)) }
            .border(if (current || dragged) 2.dp else 1.dp, borderColor, shape)
            .clickable(interactionSource = interaction, indication = null, onClick = onClick)
            .padding(start = 20.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Column(Modifier.weight(1f)) {
            Text(
                text = track.title,
                color = if (current) Neon.Light else Neon.Text,
                fontSize = 18.sp,
                fontWeight = FontWeight.SemiBold,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
            Spacer(Modifier.height(2.dp))
            Text(
                text = track.artist,
                color = Neon.Muted,
                fontSize = 14.sp,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
        }
        Spacer(Modifier.size(8.dp))
        Text(formatTime(track.durationMs), color = Neon.Muted, fontSize = 14.sp)

        // Динамик: открывает большую шкалу громкости этой песни
        val speakerInteraction = remember { MutableInteractionSource() }
        val speakerGlow = rememberPressGlow(speakerInteraction)
        Box(
            modifier = Modifier
                .width(60.dp)
                .fillMaxHeight()
                .clickable(
                    interactionSource = speakerInteraction,
                    indication = null,
                    role = Role.Button,
                    onClick = onVolume,
                )
                .semantics { contentDescription = "Громкость песни" },
            contentAlignment = Alignment.Center,
        ) {
            // Если громкость песни убавлена, динамик светлее
            val base = if (volume < 0.995f) Neon.Light else Neon.Muted
            val tint = lerp(base, Color.White, 0.7f * speakerGlow)
            Canvas(Modifier.size(width = 28.dp, height = 24.dp)) { iconSpeaker(tint, volume) }
        }

        // Три черты справа: зажмите и ведите вверх или вниз
        Box(
            modifier = Modifier
                .width(60.dp)
                .fillMaxHeight()
                .clickable(
                    interactionSource = remember { MutableInteractionSource() },
                    indication = null,
                    onClick = {},
                )
                .pointerInput(track.mediaItem.mediaId) {
                    detectDragGestures(
                        onDragStart = { startCb() },
                        onDragEnd = { endCb() },
                        onDragCancel = { endCb() },
                        onDrag = { change, amount ->
                            change.consume()
                            dragCb(amount.y)
                        },
                    )
                },
            contentAlignment = Alignment.Center,
        ) {
            val gripColor = if (dragged) Neon.Light else Neon.Muted
            Canvas(Modifier.size(width = 28.dp, height = 20.dp)) { iconGrip(gripColor) }
        }
    }
}

@Composable
fun PermissionScreen(onRequest: () -> Unit, buttonText: String) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .systemBarsPadding()
            .verticalScroll(rememberScrollState())
            .padding(32.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        NeonDisc(playing = false, modifier = Modifier.size(200.dp))
        Spacer(Modifier.height(40.dp))
        Text(
            "Нужен доступ к музыке на телефоне",
            color = Neon.Text,
            fontSize = 22.sp,
            fontWeight = FontWeight.Bold,
            textAlign = TextAlign.Center,
        )
        Spacer(Modifier.height(32.dp))
        NeonPillButton(text = buttonText, onClick = onRequest)
    }
}
