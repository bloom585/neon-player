package com.neonplayer

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.drag
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawingPadding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.max
import kotlin.math.roundToInt

/**
 * Оформление: выбор темы и ползунок цвета.
 * Фон остаётся виден, так что результат сразу можно оценить.
 * Вертикально панель стоит внизу над кнопкой закрытия, горизонтально кнопка закрытия уходит вправо.
 */
@Composable
fun SettingsScreen(onBack: () -> Unit) {
    BoxWithConstraints(Modifier.fillMaxSize()) {
        val compact = maxHeight < 480.dp
        val closeSize = if (compact) 60.dp else 72.dp

        if (compact) {
            Row(
                modifier = Modifier
                    .fillMaxSize()
                    .safeDrawingPadding()
                    .padding(horizontal = 24.dp, vertical = 12.dp),
                verticalAlignment = Alignment.Bottom,
            ) {
                SettingsPanel(compact = true, modifier = Modifier.weight(1f))
                Spacer(Modifier.width(16.dp))
                NeonButton(
                    size = closeSize,
                    description = "Закрыть настройки",
                    onClick = onBack,
                ) { iconClose(it) }
            }
        } else {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .systemBarsPadding()
                    .padding(horizontal = 24.dp, vertical = 12.dp),
            ) {
                Spacer(Modifier.weight(1f))
                SettingsPanel(compact = false, modifier = Modifier.fillMaxWidth())
                Spacer(Modifier.height(16.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.End,
                ) {
                    NeonButton(
                        size = closeSize,
                        description = "Закрыть настройки",
                        onClick = onBack,
                    ) { iconClose(it) }
                }
            }
        }
    }
}

@Composable
private fun SettingsPanel(compact: Boolean, modifier: Modifier = Modifier) {
    val context = LocalContext.current
    val panel = RoundedCornerShape(28.dp)

    Column(
        modifier = modifier
            .clip(panel)
            .background(Neon.Bg.copy(alpha = 0.80f))
            .border(1.dp, Neon.Blue.copy(alpha = 0.45f), panel)
            .padding(if (compact) 16.dp else 20.dp),
    ) {
        Text(
            "Оформление",
            color = Neon.Text,
            fontSize = if (compact) 20.sp else 24.sp,
            fontWeight = FontWeight.Bold,
        )

        Spacer(Modifier.height(if (compact) 10.dp else 18.dp))
        Text("Тема", color = Neon.Muted, fontSize = 15.sp)
        Spacer(Modifier.height(if (compact) 6.dp else 10.dp))
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            NEON_THEMES.forEachIndexed { index, spec ->
                ThemeCard(
                    index = index,
                    spec = spec,
                    selected = Neon.themeId == index,
                    compact = compact,
                    onClick = {
                        Neon.themeId = index
                        Neon.save(context)
                    },
                    modifier = Modifier.weight(1f),
                )
            }
        }

        Spacer(Modifier.height(if (compact) 10.dp else 22.dp))
        Text("Цвет", color = Neon.Muted, fontSize = 15.sp)
        Spacer(Modifier.height(4.dp))
        HueSlider(
            hue = Neon.hue,
            onChange = { Neon.hue = it },
            onDone = { Neon.save(context) },
        )
    }
}

/** Карточка темы. Показывает маленький образец в текущем цвете неона. */
@Composable
private fun ThemeCard(
    index: Int,
    spec: NeonThemeSpec,
    selected: Boolean,
    compact: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val pal = remember(Neon.hue, index) { buildPalette(index, Neon.hue) }
    val shape = RoundedCornerShape(18.dp)
    val interaction = remember { MutableInteractionSource() }
    val k = rememberPressGlow(interaction)
    val border = if (selected) pal.light else lerp(pal.dim, pal.light, k)

    Column(
        modifier = modifier
            .clip(shape)
            .background(pal.bg)
            .border(if (selected) 2.dp else 1.dp, border, shape)
            .clickable(interactionSource = interaction, indication = null, onClick = onClick)
            .semantics { contentDescription = "Тема ${spec.name}" }
            .padding(vertical = if (compact) 6.dp else 10.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Canvas(Modifier.size(if (compact) 32.dp else 44.dp)) {
            val c = center
            val r = size.minDimension / 2f
            drawCircle(pal.blue.copy(alpha = 0.25f), r, c)
            drawCircle(pal.surface, r * 0.66f, c)
            drawCircle(pal.blue, r * 0.66f, c, style = Stroke(2.dp.toPx()))
            val tri = Path().apply {
                moveTo(c.x - r * 0.15f, c.y - r * 0.28f)
                lineTo(c.x + r * 0.28f, c.y)
                lineTo(c.x - r * 0.15f, c.y + r * 0.28f)
                close()
            }
            drawPath(tri, pal.light)
        }
        Spacer(Modifier.height(if (compact) 3.dp else 6.dp))
        Text(
            spec.name,
            color = pal.text,
            fontSize = 13.sp,
            fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium,
            maxLines = 1,
        )
    }
}

/**
 * Радужный ползунок: тянете бегунок или просто касаетесь нужного цвета.
 * [onChange] вызывается на ходу, [onDone] — когда палец отпущен.
 */
@Composable
fun HueSlider(
    hue: Float,
    onChange: (Float) -> Unit,
    onDone: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val rainbow = remember { Brush.horizontalGradient(List(13) { Color.hsv(it * 30f, 0.9f, 1f) }) }
    var widthPx by remember { mutableIntStateOf(1) }
    val thumb = 40.dp
    val thumbPx = with(LocalDensity.current) { thumb.toPx() }
    val changeCb by rememberUpdatedState(onChange)
    val doneCb by rememberUpdatedState(onDone)
    val accent = Neon.Blue

    Box(
        modifier = modifier
            .fillMaxWidth()
            .height(64.dp)
            .onSizeChanged { widthPx = max(it.width, 1) }
            .pointerInput(Unit) {
                awaitEachGesture {
                    fun update(x: Float) {
                        val travel = max(widthPx - thumbPx, 1f)
                        val fraction = ((x - thumbPx / 2f) / travel).coerceIn(0f, 1f)
                        changeCb(fraction * 359.9f)
                    }

                    val down = awaitFirstDown()
                    update(down.position.x)
                    drag(down.id) { change ->
                        update(change.position.x)
                        change.consume()
                    }
                    doneCb()
                }
            }
            .semantics { contentDescription = "Цвет плеера" },
        contentAlignment = Alignment.CenterStart,
    ) {
        Box(
            Modifier
                .fillMaxWidth()
                .padding(horizontal = thumb / 2)
                .height(18.dp)
                .clip(CircleShape)
                .background(rainbow)
                .border(1.dp, Color.White.copy(alpha = 0.25f), CircleShape),
        )
        Box(
            Modifier
                .offset { IntOffset(((hue / 360f) * max(widthPx - thumbPx, 0f)).roundToInt(), 0) }
                .size(thumb)
                .neonGlow(accent, 14.dp, 0.35f)
                .clip(CircleShape)
                .background(accent)
                .border(3.dp, Color.White, CircleShape),
        )
    }
}
