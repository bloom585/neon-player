package com.neonplayer

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.PressInteraction
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.State
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.DpSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.flow.collectLatest
import kotlin.math.max

@Composable
fun NeonTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Neon.Blue,
            background = Neon.Bg,
            surface = Neon.Surface,
            onBackground = Neon.Text,
            onSurface = Neon.Text,
        ),
        content = content,
    )
}

/**
 * Фон на весь экран: картинка с котиком в наушниках, перекрашенная в выбранный цвет,
 * и бегущие по дорожкам огни.
 * [dim] от 0 до 1 — насколько затемнить картинку (на экране плеера 0, в списке 1).
 */
@Composable
fun NeonBackground(dim: Float) {
    val spec = Neon.spec
    val accent = Neon.Blue
    val imageFilter = remember(accent, spec) { neonImageFilter(accent, spec) }

    fun shade(base: Float): Float {
        val b = base * spec.scrim
        return b + (0.82f - b) * dim
    }

    Box(
        Modifier
            .fillMaxSize()
            .background(Neon.Bg),
    ) {
        Image(
            painter = painterResource(R.drawable.bg_cat),
            contentDescription = null,
            contentScale = ContentScale.Crop,
            colorFilter = imageFilter,
            modifier = Modifier.fillMaxSize(),
        )
        // Центр оставляем чистым, чтобы котик был яркий, а сверху и снизу чуть темнее ради кнопок
        Box(
            Modifier
                .fillMaxSize()
                .background(
                    Brush.verticalGradient(
                        0f to Neon.Bg.copy(alpha = shade(0.35f)),
                        0.38f to Neon.Bg.copy(alpha = shade(0f)),
                        0.62f to Neon.Bg.copy(alpha = shade(0f)),
                        1f to Neon.Bg.copy(alpha = shade(0.9f)),
                    ),
                ),
        )
        // Огни бегут поверх затемнения, в списке треков они тише
        CircuitElectrons(strength = 1f - 0.75f * dim)
    }
}

/**
 * Плавное свечение при касании: от 0 до 1.
 * При нажатии быстро разгорается, после отпускания медленно гаснет.
 * Даже при самом коротком касании свечение успевает разгореться полностью.
 */
@Composable
fun rememberPressGlow(source: MutableInteractionSource): Float {
    val glow = remember { Animatable(0f) }
    LaunchedEffect(source) {
        source.interactions.collectLatest { interaction ->
            when (interaction) {
                is PressInteraction.Press -> {
                    glow.animateTo(1f, tween(160))
                }
                is PressInteraction.Release, is PressInteraction.Cancel -> {
                    if (glow.value < 1f) glow.animateTo(1f, tween(90))
                    glow.animateTo(0f, tween(900, easing = FastOutSlowInEasing))
                }
                else -> Unit
            }
        }
    }
    return glow.value
}

/** Неоновое свечение вокруг круглого элемента. [boost] от 0 до 1 усиливает его. */
fun Modifier.neonGlow(
    color: Color,
    baseGlow: Dp,
    baseAlpha: Float,
    boost: () -> Float = { 0f },
): Modifier = this.drawBehind {
    val b = boost()
    val alpha = (baseAlpha + (0.95f - baseAlpha) * b).coerceIn(0f, 1f)
    val extra = baseGlow.toPx() * (1f + 0.7f * b)
    val radius = size.minDimension / 2f + extra
    val inner = (size.minDimension / 2f) / radius
    drawCircle(
        brush = Brush.radialGradient(
            0f to color.copy(alpha = alpha),
            inner to color.copy(alpha = alpha),
            1f to Color.Transparent,
            center = center,
            radius = radius,
        ),
        radius = radius,
        center = center,
    )
}

/** Волны сияния, которые расходятся кругами от кнопки. [phase] идёт от 0 до 1 по кругу. */
fun Modifier.neonWaves(phase: State<Float>, color: Color, reach: Dp): Modifier = this.drawBehind {
    val base = size.minDimension / 2f
    val extra = reach.toPx()
    for (i in 0 until 3) {
        val p = (phase.value + i / 3f) % 1f
        val grow = 1f - (1f - p) * (1f - p)
        val fade = (1f - p) * (1f - p)
        val radius = base + extra * grow
        // мягкое широкое сияние и тонкая яркая линия поверх
        drawCircle(
            color = color.copy(alpha = 0.22f * fade),
            radius = radius,
            center = center,
            style = Stroke(width = (16f * (1f - p) + 4f).dp.toPx()),
        )
        drawCircle(
            color = Neon.Light.copy(alpha = 0.8f * fade),
            radius = radius,
            center = center,
            style = Stroke(width = 2.5.dp.toPx()),
        )
    }
}

/**
 * Большая круглая неоновая кнопка. Иконка рисуется переданной функцией.
 * Если [pulse] включён, от кнопки расходятся волны сияния в ритме 120 ударов в минуту.
 */
@Composable
fun NeonButton(
    size: Dp,
    description: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    filled: Boolean = false,
    pulse: Boolean = false,
    icon: DrawScope.(Color) -> Unit,
) {
    val interaction = remember { MutableInteractionSource() }
    val k = rememberPressGlow(interaction)

    // Один круг фазы длится 1,5 секунды и вмещает 3 волны: волна каждые полсекунды
    val phase: State<Float>? = if (pulse) {
        rememberInfiniteTransition(label = "beat").animateFloat(
            initialValue = 0f,
            targetValue = 1f,
            animationSpec = infiniteRepeatable(tween(1500, easing = LinearEasing)),
            label = "beatPhase",
        )
    } else {
        null
    }

    // Резкая вспышка в момент «удара», потом плавное затухание до следующего
    val beat: () -> Float = {
        val p = phase?.value
        if (p == null) {
            0f
        } else {
            val f = (p * 3f) % 1f
            (1f - f) * (1f - f) * (1f - f)
        }
    }

    val borderColor =
        if (filled) lerp(Neon.Light, Color.White, 0.7f * k) else lerp(Neon.Blue, Neon.Light, k)
    val tint = if (filled) Neon.Bg else lerp(Neon.Light, Color.White, 0.7f * k)

    Box(
        modifier = modifier
            .size(size)
            .then(if (phase != null) Modifier.neonWaves(phase, Neon.Blue, 46.dp) else Modifier)
            .neonGlow(Neon.Blue, if (filled) 34.dp else 18.dp, if (filled) 0.5f else 0.28f) {
                max(k, 0.45f * beat())
            }
            .then(
                if (phase != null) {
                    Modifier.graphicsLayer {
                        val s = 1f + 0.05f * beat()
                        scaleX = s
                        scaleY = s
                    }
                } else {
                    Modifier
                },
            )
            .clip(CircleShape)
            .background(if (filled) Neon.Blue else Neon.Surface)
            .drawBehind {
                drawRect(Neon.Light.copy(alpha = (if (filled) 0.4f else 0.25f) * k))
            }
            .border(2.dp, borderColor, CircleShape)
            .clickable(
                interactionSource = interaction,
                indication = null,
                role = Role.Button,
                onClick = onClick,
            )
            .semantics { contentDescription = description },
        contentAlignment = Alignment.Center,
    ) {
        Canvas(Modifier.size(size * 0.38f)) { icon(tint) }
    }
}

/**
 * Широкая кнопка с текстом. Можно добавить значок слева: [icon] рисуется переданной функцией,
 * а [iconRotation] в градусах поворачивает его (так крутится значок при перемешивании).
 */
@Composable
fun NeonPillButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    height: Dp = 72.dp,
    icon: (DrawScope.(Color) -> Unit)? = null,
    iconRotation: Float = 0f,
) {
    val shape = RoundedCornerShape(height / 2)
    val interaction = remember { MutableInteractionSource() }
    val k = rememberPressGlow(interaction)

    Box(
        modifier = modifier
            .fillMaxWidth()
            .height(height)
            .shadow((16 + 24 * k).dp, shape, ambientColor = Neon.Blue, spotColor = Neon.Blue)
            .clip(shape)
            .background(Neon.Blue)
            .drawBehind { drawRect(Neon.Light.copy(alpha = 0.4f * k)) }
            .border(2.dp, lerp(Neon.Light, Color.White, 0.7f * k), shape)
            .clickable(
                interactionSource = interaction,
                indication = null,
                role = Role.Button,
                onClick = onClick,
            ),
        contentAlignment = Alignment.Center,
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            if (icon != null) {
                Canvas(
                    Modifier
                        .size(height * 0.36f)
                        .graphicsLayer { rotationZ = iconRotation },
                ) { icon(Neon.Bg) }
                Spacer(Modifier.width(12.dp))
            }
            Text(text, color = Neon.Bg, fontSize = 20.sp, fontWeight = FontWeight.Bold)
        }
    }
}

/** Вращающийся диск из прозрачного неонового стекла: сквозь него виден фон. */
@Composable
fun NeonDisc(playing: Boolean, modifier: Modifier = Modifier) {
    val angle = remember { Animatable(0f) }
    LaunchedEffect(playing) {
        if (playing) {
            while (true) {
                angle.animateTo(angle.value + 360f, tween(14000, easing = LinearEasing))
            }
        }
    }

    Canvas(modifier) {
        val c = center
        val r = size.minDimension / 2f
        val body = r * 0.94f

        // мягкое свечение вокруг стекла
        drawCircle(
            brush = Brush.radialGradient(
                0f to Color.Transparent,
                0.80f to Color.Transparent,
                0.92f to Neon.Blue.copy(alpha = 0.30f),
                1f to Color.Transparent,
                center = c,
                radius = r * 1.12f,
            ),
            radius = r * 1.12f,
            center = c,
        )

        // само стекло: в середине почти прозрачное, к краю чуть плотнее
        drawCircle(
            brush = Brush.radialGradient(
                0f to Neon.Light.copy(alpha = 0.02f),
                0.7f to Neon.Light.copy(alpha = 0.05f),
                1f to Neon.Blue.copy(alpha = 0.28f),
                center = c,
                radius = body,
            ),
            radius = body,
            center = c,
        )

        // светлый отсвет сверху слева, как на настоящем стекле
        drawCircle(
            brush = Brush.linearGradient(
                0f to Color.White.copy(alpha = 0.20f),
                0.45f to Color.Transparent,
                start = Offset(c.x - body, c.y - body),
                end = Offset(c.x + body * 0.2f, c.y + body * 0.2f),
            ),
            radius = body,
            center = c,
        )

        // кромка стекла
        drawCircle(Neon.Blue, radius = body, center = c, style = Stroke(3.dp.toPx()))
        drawCircle(
            Neon.Light.copy(alpha = 0.35f),
            radius = body - 6.dp.toPx(),
            center = c,
            style = Stroke(1.5.dp.toPx()),
        )

        // блики на стекле (не вращаются)
        val rs = body * 0.86f
        drawArc(
            color = Color.White.copy(alpha = 0.55f),
            startAngle = 200f,
            sweepAngle = 55f,
            useCenter = false,
            topLeft = Offset(c.x - rs, c.y - rs),
            size = Size(rs * 2, rs * 2),
            style = Stroke(5.dp.toPx(), cap = StrokeCap.Round),
        )
        drawArc(
            color = Color.White.copy(alpha = 0.25f),
            startAngle = 20f,
            sweepAngle = 25f,
            useCenter = false,
            topLeft = Offset(c.x - rs, c.y - rs),
            size = Size(rs * 2, rs * 2),
            style = Stroke(4.dp.toPx(), cap = StrokeCap.Round),
        )

        // бегущие огни по краю: показывают, что диск крутится
        rotate(angle.value % 360f, pivot = c) {
            drawArc(
                color = Neon.Light,
                startAngle = 0f,
                sweepAngle = 60f,
                useCenter = false,
                topLeft = Offset(c.x - body, c.y - body),
                size = Size(body * 2, body * 2),
                style = Stroke(5.dp.toPx(), cap = StrokeCap.Round),
            )
            drawArc(
                color = Neon.Blue,
                startAngle = 180f,
                sweepAngle = 60f,
                useCenter = false,
                topLeft = Offset(c.x - body, c.y - body),
                size = Size(body * 2, body * 2),
                style = Stroke(5.dp.toPx(), cap = StrokeCap.Round),
            )
            val r2 = body * 0.8f
            drawArc(
                color = Neon.Light.copy(alpha = 0.55f),
                startAngle = 90f,
                sweepAngle = 40f,
                useCenter = false,
                topLeft = Offset(c.x - r2, c.y - r2),
                size = Size(r2 * 2, r2 * 2),
                style = Stroke(3.dp.toPx(), cap = StrokeCap.Round),
            )
            drawArc(
                color = Neon.Light.copy(alpha = 0.55f),
                startAngle = 270f,
                sweepAngle = 40f,
                useCenter = false,
                topLeft = Offset(c.x - r2, c.y - r2),
                size = Size(r2 * 2, r2 * 2),
                style = Stroke(3.dp.toPx(), cap = StrokeCap.Round),
            )
        }
    }
}

/** Ползунок перемотки с временем. */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun NeonSeekBar(
    positionMs: Long,
    durationMs: Long,
    enabled: Boolean,
    onSeek: (Long) -> Unit,
    modifier: Modifier = Modifier,
) {
    var dragging by remember { mutableStateOf(false) }
    var dragValue by remember { mutableFloatStateOf(0f) }
    val duration = max(durationMs, 1L)
    val fraction = (positionMs.toFloat() / duration).coerceIn(0f, 1f)
    val shown = if (dragging) dragValue else fraction

    val colors = SliderDefaults.colors(
        thumbColor = Neon.Light,
        activeTrackColor = Neon.Blue,
        inactiveTrackColor = Neon.Dim,
        disabledThumbColor = Neon.Dim,
        disabledActiveTrackColor = Neon.Dim,
        disabledInactiveTrackColor = Neon.Dim,
    )
    val interaction = remember { MutableInteractionSource() }

    androidx.compose.foundation.layout.Column(modifier) {
        Slider(
            value = shown,
            onValueChange = {
                dragging = true
                dragValue = it
            },
            onValueChangeFinished = {
                onSeek((dragValue * duration).toLong())
                dragging = false
            },
            enabled = enabled,
            colors = colors,
            interactionSource = interaction,
            thumb = {
                SliderDefaults.Thumb(
                    interactionSource = interaction,
                    colors = colors,
                    enabled = enabled,
                    thumbSize = DpSize(26.dp, 26.dp),
                )
            },
            modifier = Modifier
                .fillMaxWidth()
                .height(48.dp),
        )
        androidx.compose.foundation.layout.Row(
            Modifier.fillMaxWidth(),
            horizontalArrangement = androidx.compose.foundation.layout.Arrangement.SpaceBetween,
        ) {
            val shownMs = if (dragging) (dragValue * duration).toLong() else positionMs
            Text(formatTime(shownMs), color = Neon.Muted, fontSize = 14.sp)
            Text(formatTime(durationMs), color = Neon.Muted, fontSize = 14.sp)
        }
    }
}

fun formatTime(ms: Long): String {
    val totalSeconds = (ms / 1000).coerceAtLeast(0)
    return "%d:%02d".format(totalSeconds / 60, totalSeconds % 60)
}
