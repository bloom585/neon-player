package com.neonplayer

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.drag
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawingPadding
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.max
import kotlin.math.roundToInt

/**
 * Меню громкости одной песни: название, крупные проценты и большая шкала.
 * Закрывается только своим крестиком в правом нижнем углу (и кнопкой «назад»),
 * случайное касание рядом ничего не закроет.
 */
@Composable
fun VolumeSheet(
    trackTitle: String,
    trackArtist: String,
    volume: Float,
    onChange: (Float) -> Unit,
    onDone: () -> Unit,
    onClose: () -> Unit,
    modifier: Modifier = Modifier,
) {
    BoxWithConstraints(
        modifier = modifier
            .fillMaxSize()
            .background(Neon.Bg.copy(alpha = 0.88f))
            // Съедаем касания, чтобы под меню ничего не нажималось
            .pointerInput(Unit) { detectTapGestures { } },
    ) {
        val compact = maxHeight < 480.dp
        val closeSize = if (compact) 60.dp else 72.dp

        Box(
            Modifier
                .fillMaxSize()
                .safeDrawingPadding()
                .padding(24.dp),
        ) {
            Column(
                modifier = Modifier
                    .align(Alignment.Center)
                    .padding(bottom = closeSize + 12.dp)
                    .fillMaxWidth(),
                horizontalAlignment = Alignment.CenterHorizontally,
            ) {
                Text("Громкость песни", color = Neon.Muted, fontSize = 16.sp)
                Spacer(Modifier.height(6.dp))
                Text(
                    text = trackTitle,
                    color = Neon.Text,
                    fontSize = if (compact) 18.sp else 22.sp,
                    fontWeight = FontWeight.Bold,
                    maxLines = if (compact) 1 else 2,
                    overflow = TextOverflow.Ellipsis,
                    textAlign = TextAlign.Center,
                )
                Text(
                    text = trackArtist,
                    color = Neon.Muted,
                    fontSize = 14.sp,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    textAlign = TextAlign.Center,
                )
                Spacer(Modifier.height(if (compact) 0.dp else 20.dp))
                Text(
                    text = "${(volume * 100f).roundToInt()}%",
                    color = Neon.Light,
                    fontSize = if (compact) 40.sp else 64.sp,
                    fontWeight = FontWeight.Bold,
                )
                Spacer(Modifier.height(if (compact) 0.dp else 12.dp))
                NeonBigSlider(value = volume, onChange = onChange, onDone = onDone)
            }

            NeonButton(
                size = closeSize,
                description = "Закрыть громкость",
                onClick = onClose,
                modifier = Modifier.align(Alignment.BottomEnd),
            ) { iconClose(it) }
        }
    }
}

/**
 * Очень крупная шкала: зона касания 96 dp в высоту, толстая полоса и большой бегунок.
 * Можно тянуть бегунок или просто ткнуть в нужное место шкалы.
 */
@Composable
fun NeonBigSlider(
    value: Float,
    onChange: (Float) -> Unit,
    onDone: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val changeCb by rememberUpdatedState(onChange)
    val doneCb by rememberUpdatedState(onDone)
    var widthPx by remember { mutableIntStateOf(1) }
    val thumbR = with(LocalDensity.current) { 32.dp.toPx() }

    Canvas(
        modifier = modifier
            .fillMaxWidth()
            .height(96.dp)
            .onSizeChanged { widthPx = max(it.width, 1) }
            .pointerInput(Unit) {
                awaitEachGesture {
                    fun update(x: Float) {
                        val travel = max(widthPx - 2f * thumbR, 1f)
                        changeCb(((x - thumbR) / travel).coerceIn(0f, 1f))
                    }

                    val down = awaitFirstDown()
                    update(down.position.x)
                    drag(down.id) { change ->
                        update(change.position.x)
                        change.consume()
                    }
                    doneCb()
                }
            }
            .semantics { contentDescription = "Громкость песни" },
    ) {
        val trackW = size.width - 2f * thumbR
        val th = 34.dp.toPx()
        val glow = 6.dp.toPx()
        val cy = size.height / 2f
        val x = thumbR + trackW * value.coerceIn(0f, 1f)

        // сама шкала
        drawRoundRect(
            Neon.Dim,
            Offset(thumbR, cy - th / 2f),
            Size(trackW, th),
            CornerRadius(th / 2f),
        )

        // заполненная часть со свечением
        if (x - thumbR > 1f) {
            drawRoundRect(
                Neon.Blue.copy(alpha = 0.22f),
                Offset(thumbR - glow, cy - th / 2f - glow),
                Size(x - thumbR + 2f * glow, th + 2f * glow),
                CornerRadius(th / 2f + glow),
            )
            drawRoundRect(
                brush = Brush.horizontalGradient(
                    listOf(Neon.Blue, Neon.Light),
                    startX = thumbR,
                    endX = x,
                ),
                topLeft = Offset(thumbR, cy - th / 2f),
                size = Size(x - thumbR, th),
                cornerRadius = CornerRadius(th / 2f),
            )
        }

        // большой бегунок
        val c = Offset(x, cy)
        drawCircle(
            brush = Brush.radialGradient(
                0f to Neon.Blue.copy(alpha = 0.55f),
                1f to Color.Transparent,
                center = c,
                radius = thumbR * 1.8f,
            ),
            radius = thumbR * 1.8f,
            center = c,
        )
        drawCircle(Neon.Blue, radius = thumbR, center = c)
        drawCircle(Color.White, radius = thumbR, center = c, style = Stroke(3.dp.toPx()))
    }
}
