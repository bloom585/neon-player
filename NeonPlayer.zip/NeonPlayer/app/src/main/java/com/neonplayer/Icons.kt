package com.neonplayer

import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke

// Иконки нарисованы кодом, чтобы не тянуть лишние библиотеки.

private fun DrawScope.softTriangle(path: Path, color: Color) {
    drawPath(path, color)
    drawPath(path, color, style = Stroke(width = size.width * 0.1f, join = StrokeJoin.Round))
}

fun DrawScope.iconPlay(color: Color) {
    val w = size.width
    val h = size.height
    val p = Path().apply {
        moveTo(w * 0.2f, h * 0.02f)
        lineTo(w * 0.96f, h * 0.5f)
        lineTo(w * 0.2f, h * 0.98f)
        close()
    }
    softTriangle(p, color)
}

fun DrawScope.iconPause(color: Color) {
    val w = size.width
    val h = size.height
    val bar = Size(w * 0.28f, h)
    val corner = CornerRadius(w * 0.07f)
    drawRoundRect(color, Offset(w * 0.1f, 0f), bar, corner)
    drawRoundRect(color, Offset(w * 0.62f, 0f), bar, corner)
}

fun DrawScope.iconNext(color: Color) {
    val w = size.width
    val h = size.height
    val p = Path().apply {
        moveTo(0f, h * 0.02f)
        lineTo(w * 0.76f, h * 0.5f)
        lineTo(0f, h * 0.98f)
        close()
    }
    softTriangle(p, color)
    drawRoundRect(color, Offset(w * 0.86f, 0f), Size(w * 0.14f, h), CornerRadius(w * 0.05f))
}

fun DrawScope.iconPrevious(color: Color) {
    val w = size.width
    val h = size.height
    val p = Path().apply {
        moveTo(w, h * 0.02f)
        lineTo(w * 0.24f, h * 0.5f)
        lineTo(w, h * 0.98f)
        close()
    }
    softTriangle(p, color)
    drawRoundRect(color, Offset(0f, 0f), Size(w * 0.14f, h), CornerRadius(w * 0.05f))
}

fun DrawScope.iconList(color: Color) {
    val w = size.width
    val h = size.height
    val barH = h * 0.16f
    val corner = CornerRadius(barH / 2f)
    drawRoundRect(color, Offset(0f, h * 0.06f), Size(w, barH), corner)
    drawRoundRect(color, Offset(0f, h * 0.42f), Size(w, barH), corner)
    drawRoundRect(color, Offset(0f, h * 0.78f), Size(w * 0.7f, barH), corner)
}

fun DrawScope.iconClose(color: Color) {
    val w = size.width
    val h = size.height
    val stroke = w * 0.16f
    drawLine(color, Offset(w * 0.08f, h * 0.08f), Offset(w * 0.92f, h * 0.92f), stroke, StrokeCap.Round)
    drawLine(color, Offset(w * 0.92f, h * 0.08f), Offset(w * 0.08f, h * 0.92f), stroke, StrokeCap.Round)
}
