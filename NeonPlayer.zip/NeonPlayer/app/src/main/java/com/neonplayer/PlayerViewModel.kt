package com.neonplayer

import android.app.Application
import android.content.ComponentName
import android.content.ContentUris
import android.provider.MediaStore
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.core.content.ContextCompat
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class Track(
    val mediaItem: MediaItem,
    val title: String,
    val artist: String,
    val durationMs: Long,
)

class PlayerViewModel(app: Application) : AndroidViewModel(app) {

    private var controller: MediaController? = null

    var tracks by mutableStateOf<List<Track>>(emptyList())
        private set
    var isPlaying by mutableStateOf(false)
        private set
    var title by mutableStateOf("")
        private set
    var artist by mutableStateOf("")
        private set
    var positionMs by mutableLongStateOf(0L)
        private set
    var durationMs by mutableLongStateOf(0L)
        private set
    var currentIndex by mutableIntStateOf(-1)
        private set

    private val listener = object : Player.Listener {
        override fun onEvents(player: Player, events: Player.Events) {
            sync()
        }
    }

    init {
        val token = SessionToken(app, ComponentName(app, PlaybackService::class.java))
        val future = MediaController.Builder(app, token).buildAsync()
        future.addListener(
            {
                runCatching { future.get() }.getOrNull()?.let { c ->
                    controller = c
                    c.addListener(listener)
                    c.repeatMode = Player.REPEAT_MODE_ALL
                    sync()
                }
            },
            ContextCompat.getMainExecutor(app),
        )

        // Обновляем позицию ползунка
        viewModelScope.launch {
            while (true) {
                controller?.let { positionMs = it.currentPosition }
                delay(250)
            }
        }
    }

    private fun sync() {
        val c = controller ?: return
        val hasItems = c.mediaItemCount > 0
        isPlaying = c.isPlaying ||
            (c.playWhenReady && c.playbackState == Player.STATE_BUFFERING)
        currentIndex = if (hasItems) c.currentMediaItemIndex else -1
        title = if (hasItems) c.mediaMetadata.title?.toString().orEmpty() else ""
        artist = if (hasItems) c.mediaMetadata.artist?.toString().orEmpty() else ""
        val d = c.duration
        durationMs = if (hasItems && d != C.TIME_UNSET) d else 0L
        positionMs = c.currentPosition
    }

    fun loadTracks() {
        viewModelScope.launch {
            tracks = withContext(Dispatchers.IO) { queryAudio() }
        }
    }

    private fun queryAudio(): List<Track> {
        val result = mutableListOf<Track>()
        val collection = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
        val projection = arrayOf(
            MediaStore.Audio.Media._ID,
            MediaStore.Audio.Media.TITLE,
            MediaStore.Audio.Media.ARTIST,
            MediaStore.Audio.Media.DURATION,
        )
        val selection =
            "${MediaStore.Audio.Media.IS_MUSIC} != 0 AND ${MediaStore.Audio.Media.DURATION} >= 30000"
        val sortOrder = "${MediaStore.Audio.Media.TITLE} COLLATE NOCASE ASC"

        try {
            getApplication<Application>().contentResolver
                .query(collection, projection, selection, null, sortOrder)
                ?.use { cursor ->
                    val idCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media._ID)
                    val titleCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.TITLE)
                    val artistCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.ARTIST)
                    val durCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.DURATION)

                    while (cursor.moveToNext()) {
                        val id = cursor.getLong(idCol)
                        val title = cursor.getString(titleCol)?.takeIf { it.isNotBlank() }
                            ?: "Без названия"
                        val rawArtist = cursor.getString(artistCol).orEmpty()
                        val artist = if (rawArtist.isBlank() || rawArtist == "<unknown>") {
                            "Неизвестный исполнитель"
                        } else {
                            rawArtist
                        }
                        val duration = cursor.getLong(durCol)
                        val uri = ContentUris.withAppendedId(collection, id)

                        val item = MediaItem.Builder()
                            .setMediaId(id.toString())
                            .setUri(uri)
                            .setMediaMetadata(
                                MediaMetadata.Builder()
                                    .setTitle(title)
                                    .setArtist(artist)
                                    .build(),
                            )
                            .build()

                        result += Track(item, title, artist, duration)
                    }
                }
        } catch (_: SecurityException) {
            // нет доступа к музыке — вернём пустой список
        }
        return result
    }

    fun play(index: Int) {
        val c = controller ?: return
        if (index !in tracks.indices) return
        c.setMediaItems(tracks.map { it.mediaItem }, index, 0L)
        c.prepare()
        c.play()
    }

    fun togglePlay() {
        val c = controller ?: return
        if (c.mediaItemCount == 0) {
            if (tracks.isNotEmpty()) play(0)
            return
        }
        if (c.isPlaying || c.playWhenReady) {
            c.pause()
        } else {
            if (c.playbackState == Player.STATE_IDLE) c.prepare()
            if (c.playbackState == Player.STATE_ENDED) c.seekTo(0L)
            c.play()
        }
    }

    fun next() {
        controller?.seekToNext()
    }

    fun previous() {
        controller?.seekToPrevious()
    }

    fun seekTo(ms: Long) {
        controller?.seekTo(ms)
        positionMs = ms
    }

    override fun onCleared() {
        controller?.removeListener(listener)
        controller?.release()
        controller = null
        super.onCleared()
    }
}
