package com.neonplayer

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun PlayerScreen(vm: PlayerViewModel, onOpenList: () -> Unit) {
    val hasTrack = vm.currentIndex >= 0

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 24.dp, vertical = 12.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
            NeonButton(
                size = 72.dp,
                description = "Список треков",
                onClick = onOpenList,
            ) { iconList(it) }
        }

        BoxWithConstraints(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth(),
            contentAlignment = Alignment.Center,
        ) {
            val side = minOf(maxWidth, maxHeight, 280.dp)
            NeonDisc(playing = vm.isPlaying, modifier = Modifier.size(side))
        }

        Text(
            text = if (hasTrack) vm.title else "Выберите трек",
            color = Neon.Text,
            fontSize = 24.sp,
            fontWeight = FontWeight.Bold,
            maxLines = 2,
            overflow = TextOverflow.Ellipsis,
            textAlign = TextAlign.Center,
            modifier = Modifier.fillMaxWidth(),
        )
        Spacer(Modifier.height(6.dp))
        Text(
            text = if (hasTrack) vm.artist else " ",
            color = Neon.Muted,
            fontSize = 16.sp,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            textAlign = TextAlign.Center,
            modifier = Modifier.fillMaxWidth(),
        )

        Spacer(Modifier.height(20.dp))

        NeonSeekBar(
            positionMs = vm.positionMs,
            durationMs = vm.durationMs,
            enabled = hasTrack,
            onSeek = vm::seekTo,
            modifier = Modifier.fillMaxWidth(),
        )

        Spacer(Modifier.height(20.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceEvenly,
            verticalAlignment = Alignment.CenterVertically,
        ) {
            NeonButton(
                size = 84.dp,
                description = "Предыдущий трек",
                onClick = vm::previous,
            ) { iconPrevious(it) }

            NeonButton(
                size = 128.dp,
                description = if (vm.isPlaying) "Пауза" else "Играть",
                onClick = vm::togglePlay,
                filled = true,
            ) { if (vm.isPlaying) iconPause(it) else iconPlay(it) }

            NeonButton(
                size = 84.dp,
                description = "Следующий трек",
                onClick = vm::next,
            ) { iconNext(it) }
        }

        Spacer(Modifier.height(28.dp))
    }
}

@Composable
fun TrackListScreen(vm: PlayerViewModel, onBack: () -> Unit) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 24.dp, vertical = 12.dp),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            NeonButton(
                size = 72.dp,
                description = "Закрыть список",
                onClick = onBack,
            ) { iconClose(it) }
            Spacer(Modifier.size(20.dp))
            Text("Треки", color = Neon.Text, fontSize = 28.sp, fontWeight = FontWeight.Bold)
        }

        if (vm.tracks.isEmpty()) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text("Музыка не найдена", color = Neon.Muted, fontSize = 18.sp)
            }
        } else {
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(top = 24.dp, bottom = 24.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp),
            ) {
                itemsIndexed(vm.tracks, key = { _, t -> t.mediaItem.mediaId }) { index, track ->
                    TrackRow(
                        track = track,
                        current = index == vm.currentIndex,
                        onClick = {
                            vm.play(index)
                            onBack()
                        },
                    )
                }
            }
        }
    }
}

@Composable
private fun TrackRow(track: Track, current: Boolean, onClick: () -> Unit) {
    val shape = RoundedCornerShape(22.dp)
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .heightIn(min = 80.dp)
            .clip(shape)
            .background(Neon.Surface)
            .border(if (current) 2.dp else 1.dp, if (current) Neon.Blue else Neon.Dim, shape)
            .clickable(onClick = onClick)
            .padding(horizontal = 20.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Column(Modifier.weight(1f)) {
            Text(
                text = track.title,
                color = if (current) Neon.Light else Neon.Text,
                fontSize = 18.sp,
                fontWeight = FontWeight.SemiBold,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
            Spacer(Modifier.height(2.dp))
            Text(
                text = track.artist,
                color = Neon.Muted,
                fontSize = 14.sp,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
        }
        Spacer(Modifier.size(12.dp))
        Text(formatTime(track.durationMs), color = Neon.Muted, fontSize = 14.sp)
    }
}

@Composable
fun PermissionScreen(onRequest: () -> Unit, buttonText: String) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(32.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        NeonDisc(playing = false, modifier = Modifier.size(200.dp))
        Spacer(Modifier.height(40.dp))
        Text(
            "Нужен доступ к музыке на телефоне",
            color = Neon.Text,
            fontSize = 22.sp,
            fontWeight = FontWeight.Bold,
            textAlign = TextAlign.Center,
        )
        Spacer(Modifier.height(32.dp))
        NeonPillButton(text = buttonText, onClick = onRequest)
    }
}
