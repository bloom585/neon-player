package com.neonplayer

import android.content.Context
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.roundToInt

/**
 * Настройки одной кнопки плеера: где стоит, насколько большая, как повёрнута и какого цвета.
 * Позиция хранится долями экрана (0..1) от центра кнопки, поэтому не «ломается» при повороте телефона.
 * null = «стоит на своём обычном месте / обычного цвета».
 */
class ButtonStyle(val id: String, val title: String, val baseSize: Dp) {
    var cx by mutableStateOf<Float?>(null)
    var cy by mutableStateOf<Float?>(null)
    var scale by mutableFloatStateOf(1f)
    var rotation by mutableFloatStateOf(0f)
    var hue by mutableStateOf<Float?>(null)

    val color: Color get() = hue?.let { Color.hsv(it, 0.88f, 1f) } ?: Neon.Blue
    val light: Color get() = hue?.let { lerp(Color.hsv(it, 0.88f, 1f), Color.White, 0.4f) } ?: Neon.Light

    fun reset() {
        cx = null
        cy = null
        scale = 1f
        rotation = 0f
        hue = null
    }
}

/** Все редактируемые кнопки + сохранение в память телефона. */
class ControlsState(context: Context) {
    val list = ButtonStyle("list", "Список треков", 72.dp)
    val prev = ButtonStyle("prev", "Предыдущий", 84.dp)
    val play = ButtonStyle("play", "Играть / пауза", 128.dp)
    val next = ButtonStyle("next", "Следующий", 84.dp)
    val all = listOf(list, prev, play, next)

    private val prefs = context.getSharedPreferences("controls_layout", Context.MODE_PRIVATE)

    init {
        for (b in all) {
            val k = b.id
            b.cx = if (prefs.contains("$k.cx")) prefs.getFloat("$k.cx", 0.5f) else null
            b.cy = if (prefs.contains("$k.cy")) prefs.getFloat("$k.cy", 0.5f) else null
            b.scale = prefs.getFloat("$k.scale", 1f)
            b.rotation = prefs.getFloat("$k.rot", 0f)
            b.hue = if (prefs.contains("$k.hue")) prefs.getFloat("$k.hue", 210f) else null
        }
    }

    fun save() {
        val e = prefs.edit()
        for (b in all) {
            val k = b.id
            b.cx?.let { e.putFloat("$k.cx", it) } ?: e.remove("$k.cx")
            b.cy?.let { e.putFloat("$k.cy", it) } ?: e.remove("$k.cy")
            e.putFloat("$k.scale", b.scale)
            e.putFloat("$k.rot", b.rotation)
            b.hue?.let { e.putFloat("$k.hue", it) } ?: e.remove("$k.hue")
        }
        e.apply()
    }

    fun resetAll() {
        all.forEach { it.reset() }
        save()
    }
}

/** Обычное место кнопки (центр, в dp) на экране шириной w и высотой h. */
fun defaultCenter(id: String, w: Float, h: Float): Pair<Float, Float> {
    val gap = (w - 48f - 296f) / 4f // как раньше: три кнопки с равными промежутками
    val rowY = h - 28f - 64f
    return when (id) {
        "list" -> (w - 24f - 36f) to (12f + 36f)
        "prev" -> (24f + gap + 42f) to rowY
        "play" -> (24f + 2 * gap + 84f + 64f) to rowY
        else -> (24f + 3 * gap + 84f + 128f + 42f) to rowY
    }
}

/**
 * Кнопка, которую в режиме редактирования можно таскать пальцем.
 * Размер и поворот меняются в панели [EditPanel].
 * Размеры [w] и [h] — размеры экрана в dp.
 */
@Composable
fun EditableButton(
    style: ButtonStyle,
    w: Float,
    h: Float,
    editing: Boolean,
    selected: Boolean,
    onSelect: () -> Unit,
    onCommit: () -> Unit,
    description: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    filled: Boolean = false,
    icon: DrawScope.(Color) -> Unit,
) {
    val density = LocalDensity.current
    val wPx = with(density) { w.dp.toPx() }
    val hPx = with(density) { h.dp.toPx() }
    val (dx, dy) = defaultCenter(style.id, w, h)
    val centerX by rememberUpdatedState(style.cx ?: (dx / w))
    val centerY by rememberUpdatedState(style.cy ?: (dy / h))
    val size = style.baseSize * style.scale
    val sizePx = with(density) { size.toPx() }

    Box(
        modifier = modifier
            .offset {
                IntOffset(
                    (centerX * wPx - sizePx / 2f).roundToInt(),
                    (centerY * hPx - sizePx / 2f).roundToInt(),
                )
            }
            .size(size)
            .drawBehind {
                if (editing) {
                    val r = this.size.minDimension / 2f + 10.dp.toPx()
                    drawCircle(
                        color = if (selected) Color.White else Color.White.copy(alpha = 0.35f),
                        radius = r,
                        center = center,
                        style = Stroke(
                            width = if (selected) 3.dp.toPx() else 1.5.dp.toPx(),
                            pathEffect = PathEffect.dashPathEffect(floatArrayOf(14f, 12f)),
                        ),
                    )
                }
            }
            .then(
                if (editing) {
                    Modifier.pointerInput(style) {
                        detectDragGestures(
                            onDragStart = { onSelect() },
                            onDragEnd = onCommit,
                            onDragCancel = onCommit,
                        ) { change, drag ->
                            change.consume()
                            val x = style.cx ?: centerX
                            val y = style.cy ?: centerY
                            style.cx = (x + drag.x / wPx).coerceIn(0.02f, 0.98f)
                            style.cy = (y + drag.y / hPx).coerceIn(0.02f, 0.98f)
                        }
                    }
                } else {
                    Modifier
                },
            ),
        contentAlignment = Alignment.Center,
    ) {
        NeonButton(
            size = size,
            description = description,
            onClick = if (editing) onSelect else onClick,
            modifier = Modifier.rotate(style.rotation),
            filled = filled,
            color = style.color,
            light = style.light,
            icon = icon,
        )
    }
}

/** Панель настройки выбранной кнопки: размер, поворот, цвет. */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun EditPanel(
    style: ButtonStyle,
    onCommit: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val shape = RoundedCornerShape(28.dp)
    Column(
        modifier = modifier
            .clip(shape)
            .background(Neon.Surface.copy(alpha = 0.96f))
            .border(2.dp, style.color, shape)
            // чтобы нажатия по панели не уходили на фон под ней
            .pointerInput(Unit) { detectTapGestures { } }
            .padding(horizontal = 16.dp, vertical = 10.dp),
    ) {
        Row(
            Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Text(
                style.title,
                color = Neon.Text,
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.weight(1f),
            )
            Box(
                Modifier
                    .height(44.dp)
                    .clip(CircleShape)
                    .border(1.5.dp, Neon.Light, CircleShape)
                    .clickable {
                        style.reset()
                        onCommit()
                    }
                    .padding(horizontal = 18.dp),
                contentAlignment = Alignment.Center,
            ) {
                Text("Сбросить", color = Neon.Light, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
            }
        }

        val sliderColors = SliderDefaults.colors(
            thumbColor = style.light,
            activeTrackColor = style.color,
            inactiveTrackColor = Neon.Dim,
        )

        PanelRow("Размер") {
            Slider(
                value = style.scale,
                onValueChange = { style.scale = it },
                onValueChangeFinished = onCommit,
                valueRange = 0.5f..2.2f,
                colors = sliderColors,
                modifier = Modifier.fillMaxWidth(),
            )
        }
        PanelRow("Поворот") {
            Slider(
                value = style.rotation,
                onValueChange = { style.rotation = it },
                onValueChangeFinished = onCommit,
                valueRange = 0f..360f,
                colors = sliderColors,
                modifier = Modifier.fillMaxWidth(),
            )
        }
        PanelRow("Цвет") {
            Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
                Box(
                    Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 10.dp)
                        .height(10.dp)
                        .clip(CircleShape)
                        .background(
                            Brush.horizontalGradient(
                                List(7) { Color.hsv(it * 60f, 0.88f, 1f) },
                            ),
                        ),
                )
                Slider(
                    modifier = Modifier.fillMaxWidth(),
                    value = style.hue ?: 210f,
                    onValueChange = { style.hue = it },
                    onValueChangeFinished = onCommit,
                    valueRange = 0f..360f,
                    colors = SliderDefaults.colors(
                        thumbColor = style.light,
                        activeTrackColor = Color.Transparent,
                        inactiveTrackColor = Color.Transparent,
                    ),
                )
            }
        }
    }
}

@Composable
private fun PanelRow(label: String, content: @Composable () -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .height(48.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text(label, color = Neon.Muted, fontSize = 15.sp, modifier = Modifier.width(76.dp))
        Box(Modifier.weight(1f)) { content() }
    }
}

/** Подсказка, пока ни одна кнопка не выбрана. */
@Composable
fun EditHint(modifier: Modifier = Modifier) {
    val shape = RoundedCornerShape(20.dp)
    Box(
        modifier
            .clip(shape)
            .background(Neon.Surface.copy(alpha = 0.9f))
            .border(1.dp, Neon.Dim, shape)
            .padding(horizontal = 16.dp, vertical = 10.dp),
    ) {
        Text(
            "Тяните кнопки пальцем.\nНажмите на кнопку, чтобы поменять размер, поворот и цвет.",
            color = Neon.Muted,
            fontSize = 14.sp,
        )
    }
}
