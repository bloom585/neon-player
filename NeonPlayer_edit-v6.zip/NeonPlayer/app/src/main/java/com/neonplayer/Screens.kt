package com.neonplayer

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun PlayerScreen(vm: PlayerViewModel, onOpenList: () -> Unit) {
    val hasTrack = vm.currentIndex >= 0
    val context = LocalContext.current
    val controls = remember { ControlsState(context.applicationContext) }
    var editing by rememberSaveable { mutableStateOf(false) }
    var selectedId by rememberSaveable { mutableStateOf<String?>(null) }

    fun finishEditing() {
        editing = false
        selectedId = null
        controls.save()
    }

    BackHandler(enabled = editing) { finishEditing() }

    BoxWithConstraints(Modifier.fillMaxSize()) {
        val w = maxWidth.value
        val h = maxHeight.value

        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 24.dp, vertical = 12.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            // место под верхние кнопки (карандаш и список)
            Spacer(Modifier.height(72.dp))

            BoxWithConstraints(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth(),
                contentAlignment = Alignment.Center,
            ) {
                val side = minOf(maxWidth, maxHeight, 280.dp)
                NeonDisc(playing = vm.isPlaying, modifier = Modifier.size(side))
            }

            Text(
                text = if (hasTrack) vm.title else "Выберите трек",
                color = Neon.Text,
                fontSize = 24.sp,
                fontWeight = FontWeight.Bold,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis,
                textAlign = TextAlign.Center,
                modifier = Modifier.fillMaxWidth(),
            )
            Spacer(Modifier.height(6.dp))
            Text(
                text = if (hasTrack) vm.artist else " ",
                color = Neon.Muted,
                fontSize = 16.sp,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                textAlign = TextAlign.Center,
                modifier = Modifier.fillMaxWidth(),
            )

            Spacer(Modifier.height(20.dp))

            NeonSeekBar(
                positionMs = vm.positionMs,
                durationMs = vm.durationMs,
                enabled = hasTrack,
                onSeek = vm::seekTo,
                modifier = Modifier.fillMaxWidth(),
            )

            // место под ряд кнопок управления
            Spacer(Modifier.height(20.dp + 128.dp + 28.dp))
        }

        // Фон режима редактирования: нажатие по пустому месту снимает выбор кнопки
        if (editing) {
            Box(
                Modifier
                    .fillMaxSize()
                    .clickable(
                        interactionSource = remember { MutableInteractionSource() },
                        indication = null,
                    ) { selectedId = null },
            )
        }

        // Кнопки управления: каждую можно переставить, повернуть, перекрасить и изменить в размере
        EditableButton(
            style = controls.list, w = w, h = h, editing = editing,
            selected = selectedId == controls.list.id,
            onSelect = { selectedId = controls.list.id },
            onCommit = controls::save,
            description = "Список треков",
            onClick = onOpenList,
        ) { iconList(it) }

        EditableButton(
            style = controls.prev, w = w, h = h, editing = editing,
            selected = selectedId == controls.prev.id,
            onSelect = { selectedId = controls.prev.id },
            onCommit = controls::save,
            description = "Предыдущий трек",
            onClick = vm::previous,
        ) { iconPrevious(it) }

        EditableButton(
            style = controls.play, w = w, h = h, editing = editing,
            selected = selectedId == controls.play.id,
            onSelect = { selectedId = controls.play.id },
            onCommit = controls::save,
            description = if (vm.isPlaying) "Пауза" else "Играть",
            onClick = vm::togglePlay,
            filled = true,
        ) { if (vm.isPlaying) iconPause(it) else iconPlay(it) }

        EditableButton(
            style = controls.next, w = w, h = h, editing = editing,
            selected = selectedId == controls.next.id,
            onSelect = { selectedId = controls.next.id },
            onCommit = controls::save,
            description = "Следующий трек",
            onClick = vm::next,
        ) { iconNext(it) }

        // Панель настройки выбранной кнопки или подсказка
        if (editing) {
            val sel = controls.all.firstOrNull { it.id == selectedId }
            if (sel == null) {
                EditHint(
                    Modifier
                        .align(Alignment.TopCenter)
                        .padding(top = 96.dp, start = 24.dp, end = 24.dp),
                )
            } else {
                val (dx, dy) = defaultCenter(sel.id, w, h)
                val fx = sel.cx ?: (dx / w)
                val fy = sel.cy ?: (dy / h)
                val landscape = w > h
                if (landscape) {
                    EditPanel(
                        style = sel,
                        onCommit = controls::save,
                        modifier = Modifier
                            .align(if (fx > 0.5f) Alignment.CenterStart else Alignment.CenterEnd)
                            .padding(horizontal = 16.dp)
                            .width(320.dp),
                    )
                } else {
                    EditPanel(
                        style = sel,
                        onCommit = controls::save,
                        modifier = Modifier
                            .align(if (fy > 0.5f) Alignment.TopCenter else Alignment.BottomCenter)
                            .padding(
                                start = 16.dp,
                                end = 16.dp,
                                top = if (fy > 0.5f) 96.dp else 0.dp,
                                bottom = if (fy > 0.5f) 0.dp else 16.dp,
                            )
                            .fillMaxWidth(),
                    )
                }
            }
        }

        // Карандаш: включает и выключает режим редактирования
        NeonButton(
            size = 72.dp,
            description = if (editing) "Готово" else "Редактировать кнопки",
            onClick = { if (editing) finishEditing() else editing = true },
            modifier = Modifier
                .align(Alignment.TopStart)
                .padding(start = 24.dp, top = 12.dp),
            filled = editing,
        ) { if (editing) iconCheck(it) else iconPencil(it) }
    }
}

@Composable
fun TrackListScreen(vm: PlayerViewModel, onBack: () -> Unit) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 24.dp, vertical = 12.dp),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            NeonButton(
                size = 72.dp,
                description = "Закрыть список",
                onClick = onBack,
            ) { iconClose(it) }
            Spacer(Modifier.size(20.dp))
            Text("Треки", color = Neon.Text, fontSize = 28.sp, fontWeight = FontWeight.Bold)
        }

        if (vm.tracks.isEmpty()) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text("Музыка не найдена", color = Neon.Muted, fontSize = 18.sp)
            }
        } else {
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(top = 24.dp, bottom = 24.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp),
            ) {
                itemsIndexed(vm.tracks, key = { _, t -> t.mediaItem.mediaId }) { index, track ->
                    TrackRow(
                        track = track,
                        current = index == vm.currentIndex,
                        onClick = {
                            vm.play(index)
                            onBack()
                        },
                    )
                }
            }
        }
    }
}

@Composable
private fun TrackRow(track: Track, current: Boolean, onClick: () -> Unit) {
    val shape = RoundedCornerShape(22.dp)
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .heightIn(min = 80.dp)
            .clip(shape)
            .background(Neon.Surface)
            .border(if (current) 2.dp else 1.dp, if (current) Neon.Blue else Neon.Dim, shape)
            .clickable(onClick = onClick)
            .padding(horizontal = 20.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Column(Modifier.weight(1f)) {
            Text(
                text = track.title,
                color = if (current) Neon.Light else Neon.Text,
                fontSize = 18.sp,
                fontWeight = FontWeight.SemiBold,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
            Spacer(Modifier.height(2.dp))
            Text(
                text = track.artist,
                color = Neon.Muted,
                fontSize = 14.sp,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
        }
        Spacer(Modifier.size(12.dp))
        Text(formatTime(track.durationMs), color = Neon.Muted, fontSize = 14.sp)
    }
}

@Composable
fun PermissionScreen(onRequest: () -> Unit, buttonText: String) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(32.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        NeonDisc(playing = false, modifier = Modifier.size(200.dp))
        Spacer(Modifier.height(40.dp))
        Text(
            "Нужен доступ к музыке на телефоне",
            color = Neon.Text,
            fontSize = 22.sp,
            fontWeight = FontWeight.Bold,
            textAlign = TextAlign.Center,
        )
        Spacer(Modifier.height(32.dp))
        NeonPillButton(text = buttonText, onClick = onRequest)
    }
}
