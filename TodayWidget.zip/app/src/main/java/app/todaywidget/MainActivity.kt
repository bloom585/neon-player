package app.todaywidget

import android.Manifest
import android.app.Activity
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Paint
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

class MainActivity : Activity() {

    private val accent = 0xFF8F7BFF.toInt()
    private lateinit var list: LinearLayout
    private lateinit var permButton: Button

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun roundBg(color: Int, radiusDp: Int) = GradientDrawable().apply {
        setColor(color)
        cornerRadius = dp(radiusDp).toFloat()
    }

    private fun text(content: String, sizeSp: Float, color: Int) = TextView(this).apply {
        this.text = content
        textSize = sizeSp
        setTextColor(color)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(32), dp(20), dp(24))
        }

        col.addView(text(getString(R.string.tasks_title), 26f, Color.WHITE).apply {
            setTypeface(typeface, android.graphics.Typeface.BOLD)
        })
        col.addView(text(getString(R.string.app_hint), 14f, 0xFFB8C0D9.toInt()).apply {
            setPadding(0, dp(8), 0, dp(16))
        })

        permButton = Button(this).apply {
            text = getString(R.string.perm_button)
            isAllCaps = false
            setTextColor(Color.WHITE)
            background = roundBg(accent, 14)
            setOnClickListener {
                requestPermissions(arrayOf(Manifest.permission.READ_CALENDAR), 1)
            }
        }
        col.addView(permButton, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, dp(52)
        ).apply { bottomMargin = dp(16) })

        val input = EditText(this).apply {
            hint = getString(R.string.add_hint)
            setHintTextColor(0xFF6B7391.toInt())
            setTextColor(Color.WHITE)
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_SENTENCES
            maxLines = 1
            setSingleLine(true)
            background = roundBg(0x1FFFFFFF, 14)
            setPadding(dp(16), 0, dp(16), 0)
        }
        val addButton = Button(this).apply {
            text = getString(R.string.add_button)
            isAllCaps = false
            setTextColor(Color.WHITE)
            background = roundBg(accent, 14)
        }
        val addRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            addView(input, LinearLayout.LayoutParams(0, dp(52), 1f))
            addView(addButton, LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT, dp(52)
            ).apply { marginStart = dp(10) })
        }
        col.addView(addRow)

        addButton.setOnClickListener {
            val title = input.text.toString()
            if (title.isNotBlank()) {
                TaskStore.add(this, title)
                input.text.clear()
                render()
            }
        }

        col.addView(text(getString(R.string.list_help), 12f, 0xFF6B7391.toInt()).apply {
            setPadding(dp(4), dp(16), 0, dp(8))
        })

        list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        col.addView(list)

        setContentView(ScrollView(this).apply {
            isFillViewport = true
            addView(col)
        })
    }

    override fun onResume() {
        super.onResume()
        render()
    }

    private fun hasCalendarPermission() =
        checkSelfPermission(Manifest.permission.READ_CALENDAR) == PackageManager.PERMISSION_GRANTED

    private fun render() {
        permButton.visibility = if (hasCalendarPermission()) View.GONE else View.VISIBLE
        list.removeAllViews()

        TaskStore.todayTasks(this).forEach { task ->
            val row = text(
                (if (task.done) "✓  " else "○  ") + task.title,
                16f,
                if (task.done) 0xFF6B7391.toInt() else Color.WHITE
            ).apply {
                if (task.done) paintFlags = paintFlags or Paint.STRIKE_THRU_TEXT_FLAG
                background = roundBg(0x1FFFFFFF, 14)
                setPadding(dp(16), dp(14), dp(16), dp(14))
                setOnClickListener {
                    TaskStore.toggle(this@MainActivity, task.id)
                    render()
                }
                setOnLongClickListener {
                    TaskStore.remove(this@MainActivity, task.id)
                    render()
                    true
                }
            }
            list.addView(row, LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply { bottomMargin = dp(8) })
        }

        TodayWidgetProvider.refreshAll(this)
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        render()
    }
}
