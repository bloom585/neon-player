package app.todaywidget

import android.Manifest
import android.content.ContentUris
import android.content.Context
import android.content.pm.PackageManager
import android.provider.CalendarContract
import org.json.JSONArray
import org.json.JSONObject
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.util.UUID

data class Task(val id: String, val title: String, val done: Boolean, val date: String)

/** One row in the widget: either a calendar event (taskId == null) or a local task. */
data class DayItem(val title: String, val time: String?, val done: Boolean, val taskId: String?)

object TaskStore {
    private const val PREFS = "tasks"
    private const val KEY = "list"

    fun all(context: Context): MutableList<Task> {
        val raw = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .getString(KEY, "[]") ?: "[]"
        val arr = JSONArray(raw)
        return MutableList(arr.length()) { i ->
            val o = arr.getJSONObject(i)
            Task(o.getString("id"), o.getString("title"), o.getBoolean("done"), o.getString("date"))
        }
    }

    private fun save(context: Context, list: List<Task>) {
        val arr = JSONArray()
        list.forEach {
            arr.put(
                JSONObject()
                    .put("id", it.id)
                    .put("title", it.title)
                    .put("done", it.done)
                    .put("date", it.date)
            )
        }
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit().putString(KEY, arr.toString()).apply()
    }

    fun add(context: Context, title: String) {
        val today = LocalDate.now().toString()
        // drop finished tasks from previous days while we are here
        val list = all(context).filterNot { it.done && it.date < today }.toMutableList()
        list.add(Task(UUID.randomUUID().toString(), title.trim(), false, today))
        save(context, list)
    }

    fun toggle(context: Context, id: String) {
        save(context, all(context).map { if (it.id == id) it.copy(done = !it.done) else it })
    }

    fun remove(context: Context, id: String) {
        save(context, all(context).filterNot { it.id == id })
    }

    /** Today's tasks plus unfinished ones carried over from earlier days. */
    fun todayTasks(context: Context): List<Task> {
        val today = LocalDate.now().toString() // ISO dates compare correctly as strings
        return all(context).filter { it.date == today || (!it.done && it.date < today) }
    }

    fun todayEvents(context: Context): List<DayItem> {
        if (context.checkSelfPermission(Manifest.permission.READ_CALENDAR)
            != PackageManager.PERMISSION_GRANTED
        ) return emptyList()

        val zone = ZoneId.systemDefault()
        val today = LocalDate.now(zone)
        val start = today.atStartOfDay(zone).toInstant().toEpochMilli()
        val end = today.plusDays(1).atStartOfDay(zone).toInstant().toEpochMilli()

        val builder = CalendarContract.Instances.CONTENT_URI.buildUpon()
        ContentUris.appendId(builder, start)
        ContentUris.appendId(builder, end)

        val projection = arrayOf(
            CalendarContract.Instances.TITLE,
            CalendarContract.Instances.BEGIN,
            CalendarContract.Instances.ALL_DAY
        )
        val fmt = DateTimeFormatter.ofPattern("HH:mm").withZone(zone)
        val result = mutableListOf<DayItem>()
        try {
            context.contentResolver.query(
                builder.build(),
                projection,
                "${CalendarContract.Calendars.VISIBLE}=1",
                null,
                "${CalendarContract.Instances.ALL_DAY} DESC, ${CalendarContract.Instances.BEGIN} ASC"
            )?.use { c ->
                while (c.moveToNext()) {
                    val title = c.getString(0)?.takeIf { it.isNotBlank() } ?: continue
                    val begin = c.getLong(1)
                    val allDay = c.getInt(2) == 1
                    result.add(
                        DayItem(
                            title = title,
                            time = if (allDay) null else fmt.format(Instant.ofEpochMilli(begin)),
                            done = false,
                            taskId = null
                        )
                    )
                }
            }
        } catch (_: Exception) {
            // no permission / provider unavailable: just show local tasks
        }
        return result
    }

    /** Everything the widget shows: events, then open tasks, then finished tasks. */
    fun todayItems(context: Context): List<DayItem> {
        val tasks = todayTasks(context).map { DayItem(it.title, null, it.done, it.id) }
        return todayEvents(context) + tasks.filter { !it.done } + tasks.filter { it.done }
    }
}
