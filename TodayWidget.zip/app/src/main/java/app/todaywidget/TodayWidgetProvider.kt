package app.todaywidget

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.graphics.Typeface
import android.net.Uri
import android.os.Bundle
import android.text.Spannable
import android.text.SpannableStringBuilder
import android.text.style.ForegroundColorSpan
import android.text.style.StrikethroughSpan
import android.text.style.StyleSpan
import android.view.View
import android.widget.RemoteViews
import java.time.LocalDate
import java.time.format.TextStyle
import java.util.Locale

class TodayWidgetProvider : AppWidgetProvider() {

    override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) {
        ids.forEach { update(context, manager, it) }
    }

    override fun onAppWidgetOptionsChanged(
        context: Context,
        manager: AppWidgetManager,
        id: Int,
        newOptions: Bundle
    ) {
        update(context, manager, id)
    }

    override fun onReceive(context: Context, intent: Intent) {
        super.onReceive(context, intent)
        when (intent.action) {
            Intent.ACTION_DATE_CHANGED,
            Intent.ACTION_TIME_CHANGED,
            Intent.ACTION_TIMEZONE_CHANGED,
            ACTION_REFRESH -> refreshAll(context)

            ACTION_TOGGLE -> {
                intent.getStringExtra(EXTRA_ID)?.let { TaskStore.toggle(context, it) }
                refreshAll(context)
            }
        }
    }

    companion object {
        const val ACTION_REFRESH = "app.todaywidget.REFRESH"
        const val ACTION_TOGGLE = "app.todaywidget.TOGGLE"
        const val EXTRA_ID = "task_id"

        private val ROWS = intArrayOf(
            R.id.task1, R.id.task2, R.id.task3, R.id.task4, R.id.task5, R.id.task6
        )
        private val PALETTE = intArrayOf(
            0xFF8F7BFF.toInt(), 0xFF4ADEBF.toInt(), 0xFFFFB86B.toInt(),
            0xFFFF7EB6.toInt(), 0xFF6EC1FF.toInt(), 0xFFB5E36B.toInt()
        )
        private const val MUTED = 0xFF6B7391.toInt()
        private const val FLAG = Spannable.SPAN_EXCLUSIVE_EXCLUSIVE

        fun refreshAll(context: Context) {
            val manager = AppWidgetManager.getInstance(context)
            val ids = manager.getAppWidgetIds(ComponentName(context, TodayWidgetProvider::class.java))
            ids.forEach { update(context, manager, it) }
        }

        private fun update(context: Context, manager: AppWidgetManager, id: Int) {
            val locale = Locale.getDefault()
            val today = LocalDate.now()
            val views = RemoteViews(context.packageName, R.layout.widget_today)

            views.setTextViewText(R.id.day_number, today.dayOfMonth.toString())
            views.setTextViewText(
                R.id.weekday,
                today.dayOfWeek.getDisplayName(TextStyle.FULL, locale).uppercase(locale)
            )
            val month = today.month.getDisplayName(TextStyle.FULL_STANDALONE, locale)
                .replaceFirstChar { it.titlecase(locale) }
            views.setTextViewText(R.id.month_year, "$month ${today.year}")

            // how many rows fit into the current widget height
            val minH = manager.getAppWidgetOptions(id)
                .getInt(AppWidgetManager.OPTION_APPWIDGET_MIN_HEIGHT, 250)
            val capacity = ((minH - 170) / 46).coerceIn(1, ROWS.size)

            val items = TaskStore.todayItems(context)
            val pending = items.count { !it.done }
            val shown = if (items.size > capacity) maxOf(capacity - 1, 1) else items.size

            views.setTextViewText(
                R.id.badge,
                if (pending > 0) context.getString(R.string.badge_left, pending)
                else context.getString(R.string.badge_done)
            )

            val openApp = PendingIntent.getActivity(
                context, 0, Intent(context, MainActivity::class.java),
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            views.setOnClickPendingIntent(R.id.root, openApp)

            ROWS.forEachIndexed { index, rowId ->
                if (index < shown) {
                    val item = items[index]
                    views.setViewVisibility(rowId, View.VISIBLE)
                    views.setTextViewText(rowId, rowText(item, index))
                    views.setOnClickPendingIntent(
                        rowId,
                        if (item.taskId != null) togglePending(context, item.taskId) else openApp
                    )
                } else {
                    views.setViewVisibility(rowId, View.GONE)
                }
            }

            val hidden = items.size - shown
            if (hidden > 0) {
                views.setViewVisibility(R.id.more_view, View.VISIBLE)
                views.setTextViewText(R.id.more_view, context.getString(R.string.more_format, hidden))
            } else {
                views.setViewVisibility(R.id.more_view, View.GONE)
            }
            views.setViewVisibility(R.id.empty_view, if (items.isEmpty()) View.VISIBLE else View.GONE)

            manager.updateAppWidget(id, views)
        }

        private fun togglePending(context: Context, taskId: String): PendingIntent {
            val intent = Intent(context, TodayWidgetProvider::class.java)
                .setAction(ACTION_TOGGLE)
                .setData(Uri.parse("todaywidget://toggle/$taskId")) // makes each PendingIntent unique
                .putExtra(EXTRA_ID, taskId)
            return PendingIntent.getBroadcast(
                context, 0, intent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
        }

        private fun rowText(item: DayItem, index: Int): CharSequence {
            val accent = PALETTE[index % PALETTE.size]
            val sb = SpannableStringBuilder()

            val marker = when {
                item.done -> "✓"
                item.taskId != null -> "○"
                else -> "●"
            }
            sb.append(marker, ForegroundColorSpan(if (item.done) MUTED else accent), FLAG)
            sb.append("  ")

            if (item.time != null) {
                val start = sb.length
                sb.append(item.time)
                sb.setSpan(ForegroundColorSpan(accent), start, sb.length, FLAG)
                sb.setSpan(StyleSpan(Typeface.BOLD), start, sb.length, FLAG)
                sb.append("  ")
            }

            val titleStart = sb.length
            sb.append(item.title)
            if (item.done) {
                sb.setSpan(StrikethroughSpan(), titleStart, sb.length, FLAG)
                sb.setSpan(ForegroundColorSpan(MUTED), titleStart, sb.length, FLAG)
            }
            return sb
        }
    }
}
